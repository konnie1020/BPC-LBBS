﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace LBBS_system
{
    public partial class adminmenu : Form
    {
        private bool topMenuExpand = false;
        private bool sidebarExpand = false; // Track whether the sidebar is expanded
        private bool isAnimating = false; // Prevent multiple triggers

        public adminmenu()
        {
            InitializeComponent();
        }

        private void adminmenu_Load(object sender, EventArgs e)
        {
            flpMenu.Width = flpMenu.MinimumSize.Width;
           
        }

        private void label1_Click(object sender, EventArgs e)
        {
        }

        private void sidebarTimer_Tick(object sender, EventArgs e)
        {
            if (sidebarExpand)
            {
                // Expand the sidebar
                flpMenu.Width += 10; // Adjust for speed of expansion
                if (flpMenu.Width >= flpMenu.MaximumSize.Width)
                {
                    flpMenu.Width = flpMenu.MaximumSize.Width; // Snap to max size
                    isAnimating = false; // Stop animation
                    sidebarTimer.Stop();
                }
            }
            else
            {
                // Collapse the sidebar
                flpMenu.Width -= 10; // Adjust for speed of collapse
                if (flpMenu.Width <= flpMenu.MinimumSize.Width)
                {
                    flpMenu.Width = flpMenu.MinimumSize.Width; // Snap to min size
                    isAnimating = false; // Stop animation
                    sidebarTimer.Stop();
                }
            }
        }

        private void btnmenu_Click(object sender, EventArgs e)
        {
            if (!isAnimating) // Prevent repeated triggering while animating
            {
                isAnimating = true;
                sidebarExpand = !sidebarExpand; // Toggle between expanding and collapsing
                sidebarTimer.Start(); // Start the animation timer
            }
        }

        private void button1_Click(object sender, EventArgs e)
        {
            // Create and show the ForgotPasswordForm when the link is clicked
            borrowerList borrowerList = new borrowerList();
            borrowerList.Show(); // Opens the new form
            this.Hide(); // Optionally hide the current form (LoginForm)
        }

        private void flpMenu_Paint(object sender, PaintEventArgs e)
        {

        }

        private void label2_Click(object sender, EventArgs e)
        {

        }

        private void btnprofile_Click(object sender, EventArgs e)
        {
            if (!isAnimating) // Prevent repeated triggering
            {
                isAnimating = true;
                topMenuExpand = !topMenuExpand; // Toggle expand/collapse state
                Profiletimer.Start();
            }

        }

       /* private void Profiletimer_Tick(object sender, EventArgs e)
        {
            if (topMenuExpand)
            {
                // Expand the menu
                flpprofile.Height += 10; // Adjust for speed
                if (flpprofile.Height >= flpprofile.MaximumSize.Height)
                {
                    flpprofile.Height = flpprofile.MaximumSize.Height; // Snap to max height
                    isAnimating = false;
                    Profiletimer.Stop();
                }
            }
            else
            {
                // Collapse the menu
                flpprofile.Height -= 10; // Adjust for speed
                if (flpprofile.Height <= flpprofile.MinimumSize.Height)
                {
                    flpprofile.Height = flpprofile.MinimumSize.Height; // Snap to min height
                    isAnimating = false;
                    Profiletimer.Stop();
                }
            }
        }

        private void flpprofile_Paint(object sender, PaintEventArgs e)
        {

        }*/

        private void button2_Click(object sender, EventArgs e)
        {
            // Create and show the ForgotPasswordForm when the link is clicked
            login Form1 = new login();
            Form1.Show(); // Opens the new form
            this.Hide(); // Optionally hide the current form (LoginForm)
        }

        private void button1_Click_1(object sender, EventArgs e)
        {
            forgotpass forgotpass = new forgotpass();
            forgotpass.Show();
            this.Hide();

        }

        private void btnuserlist_Click(object sender, EventArgs e)
        {
            userlist userlist = new userlist();
            userlist.Show();
            this.Hide();

        }

        private void btnrecords_Click(object sender, EventArgs e)
        {
            Records records = new Records();
            records.Show();
            this.Hide();
        }

        private void btninven_Click(object sender, EventArgs e)
        {
            Inventory Inventory = new Inventory();
            Inventory.Show();
            this.Hide();
        }

        private void button6_Click(object sender, EventArgs e)
        {

        }

        private void btnHome_Click(object sender, EventArgs e)
        {

        }

       
            

        private void button1_Click_3(object sender, EventArgs e)
        {
            StudentList studentlist = new StudentList();
            studentlist.Show();
            this.Hide();
        }
    }
    }
    

