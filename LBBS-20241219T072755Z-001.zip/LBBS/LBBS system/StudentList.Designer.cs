﻿namespace LBBS_system
{
    partial class StudentList
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.components = new System.ComponentModel.Container();
            System.ComponentModel.ComponentResourceManager resources = new System.ComponentModel.ComponentResourceManager(typeof(StudentList));
            this.label1 = new System.Windows.Forms.Label();
            this.tbID = new System.Windows.Forms.TextBox();
            this.dgvUser = new System.Windows.Forms.DataGridView();
            this.btnsave = new System.Windows.Forms.Button();
            this.tbfn = new System.Windows.Forms.TextBox();
            this.label2 = new System.Windows.Forms.Label();
            this.tbln = new System.Windows.Forms.TextBox();
            this.label3 = new System.Windows.Forms.Label();
            this.tbemail = new System.Windows.Forms.TextBox();
            this.label4 = new System.Windows.Forms.Label();
            this.btnupdate = new System.Windows.Forms.Button();
            this.btnclear = new System.Windows.Forms.Button();
            this.btndel = new System.Windows.Forms.Button();
            this.flpMenu = new System.Windows.Forms.FlowLayoutPanel();
            this.panel2 = new System.Windows.Forms.Panel();
            this.menubtn = new System.Windows.Forms.PictureBox();
            this.label5 = new System.Windows.Forms.Label();
            this.panel3 = new System.Windows.Forms.Panel();
            this.btnHome = new System.Windows.Forms.Button();
            this.panel1 = new System.Windows.Forms.Panel();
            this.btnborrowlist = new System.Windows.Forms.Button();
            this.panel4 = new System.Windows.Forms.Panel();
            this.btnuserlist = new System.Windows.Forms.Button();
            this.panel8 = new System.Windows.Forms.Panel();
            this.btnrecords = new System.Windows.Forms.Button();
            this.panel9 = new System.Windows.Forms.Panel();
            this.btninven = new System.Windows.Forms.Button();
            this.panel11 = new System.Windows.Forms.Panel();
            this.button2 = new System.Windows.Forms.Button();
            this.panel5 = new System.Windows.Forms.Panel();
            this.button1 = new System.Windows.Forms.Button();
            this.sidebarTimer = new System.Windows.Forms.Timer(this.components);
            ((System.ComponentModel.ISupportInitialize)(this.dgvUser)).BeginInit();
            this.flpMenu.SuspendLayout();
            this.panel2.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.menubtn)).BeginInit();
            this.panel3.SuspendLayout();
            this.panel1.SuspendLayout();
            this.panel4.SuspendLayout();
            this.panel8.SuspendLayout();
            this.panel9.SuspendLayout();
            this.panel11.SuspendLayout();
            this.panel5.SuspendLayout();
            this.SuspendLayout();
            // 
            // label1
            // 
            this.label1.AutoSize = true;
            this.label1.Font = new System.Drawing.Font("Microsoft Sans Serif", 10.8F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label1.ForeColor = System.Drawing.Color.White;
            this.label1.Location = new System.Drawing.Point(148, 217);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(96, 24);
            this.label1.TabIndex = 0;
            this.label1.Text = "Student ID";
            // 
            // tbID
            // 
            this.tbID.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.tbID.Location = new System.Drawing.Point(266, 211);
            this.tbID.Name = "tbID";
            this.tbID.Size = new System.Drawing.Size(218, 30);
            this.tbID.TabIndex = 1;
            this.tbID.TextChanged += new System.EventHandler(this.textBox1_TextChanged);
            // 
            // dgvUser
            // 
            this.dgvUser.AutoSizeColumnsMode = System.Windows.Forms.DataGridViewAutoSizeColumnsMode.Fill;
            this.dgvUser.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            this.dgvUser.Location = new System.Drawing.Point(507, 33);
            this.dgvUser.Name = "dgvUser";
            this.dgvUser.RowTemplate.Height = 24;
            this.dgvUser.Size = new System.Drawing.Size(931, 479);
            this.dgvUser.TabIndex = 2;
            this.dgvUser.CellClick += new System.Windows.Forms.DataGridViewCellEventHandler(this.dgvUser_CellClick);
            this.dgvUser.CellContentClick += new System.Windows.Forms.DataGridViewCellEventHandler(this.dataGridView1_CellContentClick);
            this.dgvUser.CellEnter += new System.Windows.Forms.DataGridViewCellEventHandler(this.dgvUser_CellEnter);
            // 
            // btnsave
            // 
            this.btnsave.BackColor = System.Drawing.Color.Yellow;
            this.btnsave.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.btnsave.Location = new System.Drawing.Point(507, 566);
            this.btnsave.Name = "btnsave";
            this.btnsave.Size = new System.Drawing.Size(158, 47);
            this.btnsave.TabIndex = 3;
            this.btnsave.Text = "Save";
            this.btnsave.UseVisualStyleBackColor = false;
            this.btnsave.Click += new System.EventHandler(this.btnsave_Click);
            // 
            // tbfn
            // 
            this.tbfn.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.tbfn.Location = new System.Drawing.Point(266, 259);
            this.tbfn.Name = "tbfn";
            this.tbfn.Size = new System.Drawing.Size(218, 30);
            this.tbfn.TabIndex = 5;
            // 
            // label2
            // 
            this.label2.AutoSize = true;
            this.label2.Font = new System.Drawing.Font("Microsoft Sans Serif", 10.8F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label2.ForeColor = System.Drawing.Color.White;
            this.label2.Location = new System.Drawing.Point(148, 265);
            this.label2.Name = "label2";
            this.label2.Size = new System.Drawing.Size(96, 24);
            this.label2.TabIndex = 4;
            this.label2.Text = "FirstName";
            // 
            // tbln
            // 
            this.tbln.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.tbln.Location = new System.Drawing.Point(266, 309);
            this.tbln.Name = "tbln";
            this.tbln.Size = new System.Drawing.Size(218, 30);
            this.tbln.TabIndex = 7;
            // 
            // label3
            // 
            this.label3.AutoSize = true;
            this.label3.Font = new System.Drawing.Font("Microsoft Sans Serif", 10.8F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label3.ForeColor = System.Drawing.Color.White;
            this.label3.Location = new System.Drawing.Point(148, 315);
            this.label3.Name = "label3";
            this.label3.Size = new System.Drawing.Size(94, 24);
            this.label3.TabIndex = 6;
            this.label3.Text = "LastName";
            // 
            // tbemail
            // 
            this.tbemail.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.tbemail.Location = new System.Drawing.Point(266, 354);
            this.tbemail.Name = "tbemail";
            this.tbemail.Size = new System.Drawing.Size(218, 30);
            this.tbemail.TabIndex = 9;
            // 
            // label4
            // 
            this.label4.AutoSize = true;
            this.label4.Font = new System.Drawing.Font("Microsoft Sans Serif", 10.8F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label4.ForeColor = System.Drawing.Color.White;
            this.label4.Location = new System.Drawing.Point(183, 360);
            this.label4.Name = "label4";
            this.label4.Size = new System.Drawing.Size(57, 24);
            this.label4.TabIndex = 8;
            this.label4.Text = "Email";
            // 
            // btnupdate
            // 
            this.btnupdate.BackColor = System.Drawing.Color.Yellow;
            this.btnupdate.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.btnupdate.Location = new System.Drawing.Point(671, 566);
            this.btnupdate.Name = "btnupdate";
            this.btnupdate.Size = new System.Drawing.Size(158, 47);
            this.btnupdate.TabIndex = 10;
            this.btnupdate.Text = "Update";
            this.btnupdate.UseVisualStyleBackColor = false;
            this.btnupdate.Click += new System.EventHandler(this.btnupdate_Click);
            // 
            // btnclear
            // 
            this.btnclear.BackColor = System.Drawing.Color.Yellow;
            this.btnclear.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.btnclear.Location = new System.Drawing.Point(835, 566);
            this.btnclear.Name = "btnclear";
            this.btnclear.Size = new System.Drawing.Size(158, 47);
            this.btnclear.TabIndex = 11;
            this.btnclear.Text = "Clear";
            this.btnclear.UseVisualStyleBackColor = false;
            this.btnclear.Click += new System.EventHandler(this.btnclear_Click);
            // 
            // btndel
            // 
            this.btndel.BackColor = System.Drawing.Color.Yellow;
            this.btndel.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.btndel.Location = new System.Drawing.Point(999, 566);
            this.btndel.Name = "btndel";
            this.btndel.Size = new System.Drawing.Size(158, 47);
            this.btndel.TabIndex = 12;
            this.btndel.Text = "Delete";
            this.btndel.UseVisualStyleBackColor = false;
            this.btndel.Click += new System.EventHandler(this.btndel_Click);
            // 
            // flpMenu
            // 
            this.flpMenu.BackColor = System.Drawing.Color.ForestGreen;
            this.flpMenu.Controls.Add(this.panel2);
            this.flpMenu.Controls.Add(this.panel3);
            this.flpMenu.Controls.Add(this.panel1);
            this.flpMenu.Controls.Add(this.panel4);
            this.flpMenu.Controls.Add(this.panel8);
            this.flpMenu.Controls.Add(this.panel9);
            this.flpMenu.Controls.Add(this.panel11);
            this.flpMenu.Controls.Add(this.panel5);
            this.flpMenu.Dock = System.Windows.Forms.DockStyle.Left;
            this.flpMenu.Location = new System.Drawing.Point(0, 0);
            this.flpMenu.Margin = new System.Windows.Forms.Padding(4);
            this.flpMenu.MaximumSize = new System.Drawing.Size(336, 692);
            this.flpMenu.MinimumSize = new System.Drawing.Size(91, 690);
            this.flpMenu.Name = "flpMenu";
            this.flpMenu.Size = new System.Drawing.Size(336, 690);
            this.flpMenu.TabIndex = 34;
            // 
            // panel2
            // 
            this.panel2.Controls.Add(this.menubtn);
            this.panel2.Controls.Add(this.label5);
            this.panel2.Location = new System.Drawing.Point(4, 4);
            this.panel2.Margin = new System.Windows.Forms.Padding(4);
            this.panel2.Name = "panel2";
            this.panel2.Size = new System.Drawing.Size(332, 127);
            this.panel2.TabIndex = 2;
            // 
            // menubtn
            // 
            this.menubtn.Cursor = System.Windows.Forms.Cursors.Hand;
            this.menubtn.Image = ((System.Drawing.Image)(resources.GetObject("menubtn.Image")));
            this.menubtn.Location = new System.Drawing.Point(12, 33);
            this.menubtn.Margin = new System.Windows.Forms.Padding(4);
            this.menubtn.Name = "menubtn";
            this.menubtn.Size = new System.Drawing.Size(67, 49);
            this.menubtn.SizeMode = System.Windows.Forms.PictureBoxSizeMode.StretchImage;
            this.menubtn.TabIndex = 1;
            this.menubtn.TabStop = false;
            this.menubtn.Click += new System.EventHandler(this.menubtn_Click);
            // 
            // label5
            // 
            this.label5.AutoSize = true;
            this.label5.Font = new System.Drawing.Font("Segoe UI", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label5.ForeColor = System.Drawing.Color.White;
            this.label5.Location = new System.Drawing.Point(87, 46);
            this.label5.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.label5.Name = "label5";
            this.label5.Size = new System.Drawing.Size(69, 28);
            this.label5.TabIndex = 1;
            this.label5.Text = "MENU";
            // 
            // panel3
            // 
            this.panel3.Controls.Add(this.btnHome);
            this.panel3.Location = new System.Drawing.Point(4, 139);
            this.panel3.Margin = new System.Windows.Forms.Padding(4);
            this.panel3.Name = "panel3";
            this.panel3.Size = new System.Drawing.Size(332, 52);
            this.panel3.TabIndex = 3;
            // 
            // btnHome
            // 
            this.btnHome.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.btnHome.Font = new System.Drawing.Font("Segoe UI", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btnHome.ForeColor = System.Drawing.Color.White;
            this.btnHome.ImageAlign = System.Drawing.ContentAlignment.MiddleLeft;
            this.btnHome.Location = new System.Drawing.Point(-2, -18);
            this.btnHome.Margin = new System.Windows.Forms.Padding(4);
            this.btnHome.Name = "btnHome";
            this.btnHome.Size = new System.Drawing.Size(367, 89);
            this.btnHome.TabIndex = 2;
            this.btnHome.Text = "                Home";
            this.btnHome.TextAlign = System.Drawing.ContentAlignment.MiddleLeft;
            this.btnHome.UseVisualStyleBackColor = true;
            this.btnHome.Click += new System.EventHandler(this.btnHome_Click);
            // 
            // panel1
            // 
            this.panel1.Controls.Add(this.btnborrowlist);
            this.panel1.Location = new System.Drawing.Point(4, 199);
            this.panel1.Margin = new System.Windows.Forms.Padding(4);
            this.panel1.Name = "panel1";
            this.panel1.Size = new System.Drawing.Size(332, 52);
            this.panel1.TabIndex = 1;
            // 
            // btnborrowlist
            // 
            this.btnborrowlist.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.btnborrowlist.Font = new System.Drawing.Font("Segoe UI", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btnborrowlist.ForeColor = System.Drawing.Color.White;
            this.btnborrowlist.ImageAlign = System.Drawing.ContentAlignment.MiddleLeft;
            this.btnborrowlist.Location = new System.Drawing.Point(-4, -18);
            this.btnborrowlist.Margin = new System.Windows.Forms.Padding(4);
            this.btnborrowlist.Name = "btnborrowlist";
            this.btnborrowlist.Size = new System.Drawing.Size(367, 89);
            this.btnborrowlist.TabIndex = 2;
            this.btnborrowlist.Text = "                Borrower List";
            this.btnborrowlist.TextAlign = System.Drawing.ContentAlignment.MiddleLeft;
            this.btnborrowlist.UseVisualStyleBackColor = true;
            this.btnborrowlist.Click += new System.EventHandler(this.btnborrowlist_Click);
            // 
            // panel4
            // 
            this.panel4.Controls.Add(this.btnuserlist);
            this.panel4.Location = new System.Drawing.Point(4, 259);
            this.panel4.Margin = new System.Windows.Forms.Padding(4);
            this.panel4.Name = "panel4";
            this.panel4.Size = new System.Drawing.Size(332, 52);
            this.panel4.TabIndex = 3;
            // 
            // btnuserlist
            // 
            this.btnuserlist.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.btnuserlist.Font = new System.Drawing.Font("Segoe UI", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btnuserlist.ForeColor = System.Drawing.Color.White;
            this.btnuserlist.ImageAlign = System.Drawing.ContentAlignment.MiddleLeft;
            this.btnuserlist.Location = new System.Drawing.Point(-2, -18);
            this.btnuserlist.Margin = new System.Windows.Forms.Padding(4);
            this.btnuserlist.Name = "btnuserlist";
            this.btnuserlist.Size = new System.Drawing.Size(367, 89);
            this.btnuserlist.TabIndex = 2;
            this.btnuserlist.Text = "                User List";
            this.btnuserlist.TextAlign = System.Drawing.ContentAlignment.MiddleLeft;
            this.btnuserlist.UseVisualStyleBackColor = true;
            this.btnuserlist.Click += new System.EventHandler(this.btnuserlist_Click);
            // 
            // panel8
            // 
            this.panel8.Controls.Add(this.btnrecords);
            this.panel8.Location = new System.Drawing.Point(4, 319);
            this.panel8.Margin = new System.Windows.Forms.Padding(4);
            this.panel8.Name = "panel8";
            this.panel8.Size = new System.Drawing.Size(332, 52);
            this.panel8.TabIndex = 8;
            // 
            // btnrecords
            // 
            this.btnrecords.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.btnrecords.Font = new System.Drawing.Font("Segoe UI", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btnrecords.ForeColor = System.Drawing.Color.White;
            this.btnrecords.ImageAlign = System.Drawing.ContentAlignment.MiddleLeft;
            this.btnrecords.Location = new System.Drawing.Point(-2, -16);
            this.btnrecords.Margin = new System.Windows.Forms.Padding(4);
            this.btnrecords.Name = "btnrecords";
            this.btnrecords.Size = new System.Drawing.Size(367, 89);
            this.btnrecords.TabIndex = 2;
            this.btnrecords.Text = "                Records\r\n\r\n";
            this.btnrecords.TextAlign = System.Drawing.ContentAlignment.MiddleLeft;
            this.btnrecords.UseVisualStyleBackColor = true;
            this.btnrecords.Click += new System.EventHandler(this.btnrecords_Click);
            // 
            // panel9
            // 
            this.panel9.Controls.Add(this.btninven);
            this.panel9.Location = new System.Drawing.Point(4, 379);
            this.panel9.Margin = new System.Windows.Forms.Padding(4);
            this.panel9.Name = "panel9";
            this.panel9.Size = new System.Drawing.Size(332, 52);
            this.panel9.TabIndex = 9;
            // 
            // btninven
            // 
            this.btninven.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.btninven.Font = new System.Drawing.Font("Segoe UI", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btninven.ForeColor = System.Drawing.Color.White;
            this.btninven.ImageAlign = System.Drawing.ContentAlignment.MiddleLeft;
            this.btninven.Location = new System.Drawing.Point(-2, -18);
            this.btninven.Margin = new System.Windows.Forms.Padding(4);
            this.btninven.Name = "btninven";
            this.btninven.Size = new System.Drawing.Size(367, 89);
            this.btninven.TabIndex = 2;
            this.btninven.Text = "                Inventory";
            this.btninven.TextAlign = System.Drawing.ContentAlignment.MiddleLeft;
            this.btninven.UseVisualStyleBackColor = true;
            this.btninven.Click += new System.EventHandler(this.btninven_Click);
            // 
            // panel11
            // 
            this.panel11.Controls.Add(this.button2);
            this.panel11.Location = new System.Drawing.Point(4, 439);
            this.panel11.Margin = new System.Windows.Forms.Padding(4);
            this.panel11.Name = "panel11";
            this.panel11.Size = new System.Drawing.Size(332, 52);
            this.panel11.TabIndex = 29;
            // 
            // button2
            // 
            this.button2.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.button2.Font = new System.Drawing.Font("Segoe UI", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.button2.ForeColor = System.Drawing.Color.White;
            this.button2.ImageAlign = System.Drawing.ContentAlignment.MiddleLeft;
            this.button2.Location = new System.Drawing.Point(-1, -16);
            this.button2.Margin = new System.Windows.Forms.Padding(4);
            this.button2.Name = "button2";
            this.button2.Size = new System.Drawing.Size(367, 89);
            this.button2.TabIndex = 2;
            this.button2.Text = "                Log Out";
            this.button2.TextAlign = System.Drawing.ContentAlignment.MiddleLeft;
            this.button2.UseVisualStyleBackColor = true;
            this.button2.Click += new System.EventHandler(this.button2_Click);
            // 
            // panel5
            // 
            this.panel5.Controls.Add(this.button1);
            this.panel5.Location = new System.Drawing.Point(4, 499);
            this.panel5.Margin = new System.Windows.Forms.Padding(4);
            this.panel5.Name = "panel5";
            this.panel5.Size = new System.Drawing.Size(332, 52);
            this.panel5.TabIndex = 30;
            // 
            // button1
            // 
            this.button1.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.button1.Font = new System.Drawing.Font("Segoe UI", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.button1.ForeColor = System.Drawing.Color.White;
            this.button1.ImageAlign = System.Drawing.ContentAlignment.MiddleLeft;
            this.button1.Location = new System.Drawing.Point(-1, -16);
            this.button1.Margin = new System.Windows.Forms.Padding(4);
            this.button1.Name = "button1";
            this.button1.Size = new System.Drawing.Size(367, 89);
            this.button1.TabIndex = 2;
            this.button1.Text = "                Student List";
            this.button1.TextAlign = System.Drawing.ContentAlignment.MiddleLeft;
            this.button1.UseVisualStyleBackColor = true;
            this.button1.Click += new System.EventHandler(this.button1_Click);
            // 
            // sidebarTimer
            // 
            this.sidebarTimer.Interval = 10;
            this.sidebarTimer.Tick += new System.EventHandler(this.sidebarTimer_Tick);
            // 
            // StudentList
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(8F, 16F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.BackColor = System.Drawing.Color.DarkGreen;
            this.ClientSize = new System.Drawing.Size(1497, 685);
            this.Controls.Add(this.flpMenu);
            this.Controls.Add(this.btndel);
            this.Controls.Add(this.btnclear);
            this.Controls.Add(this.btnupdate);
            this.Controls.Add(this.tbemail);
            this.Controls.Add(this.label4);
            this.Controls.Add(this.tbln);
            this.Controls.Add(this.label3);
            this.Controls.Add(this.tbfn);
            this.Controls.Add(this.label2);
            this.Controls.Add(this.btnsave);
            this.Controls.Add(this.dgvUser);
            this.Controls.Add(this.tbID);
            this.Controls.Add(this.label1);
            this.Name = "StudentList";
            this.Text = "StudentList";
            this.Load += new System.EventHandler(this.StudentList_Load);
            ((System.ComponentModel.ISupportInitialize)(this.dgvUser)).EndInit();
            this.flpMenu.ResumeLayout(false);
            this.panel2.ResumeLayout(false);
            this.panel2.PerformLayout();
            ((System.ComponentModel.ISupportInitialize)(this.menubtn)).EndInit();
            this.panel3.ResumeLayout(false);
            this.panel1.ResumeLayout(false);
            this.panel4.ResumeLayout(false);
            this.panel8.ResumeLayout(false);
            this.panel9.ResumeLayout(false);
            this.panel11.ResumeLayout(false);
            this.panel5.ResumeLayout(false);
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.Label label1;
        private System.Windows.Forms.TextBox tbID;
        private System.Windows.Forms.DataGridView dgvUser;
        private System.Windows.Forms.Button btnsave;
        private System.Windows.Forms.TextBox tbfn;
        private System.Windows.Forms.Label label2;
        private System.Windows.Forms.TextBox tbln;
        private System.Windows.Forms.Label label3;
        private System.Windows.Forms.TextBox tbemail;
        private System.Windows.Forms.Label label4;
        private System.Windows.Forms.Button btnupdate;
        private System.Windows.Forms.Button btnclear;
        private System.Windows.Forms.Button btndel;
        private System.Windows.Forms.FlowLayoutPanel flpMenu;
        private System.Windows.Forms.Panel panel2;
        private System.Windows.Forms.PictureBox menubtn;
        private System.Windows.Forms.Label label5;
        private System.Windows.Forms.Panel panel3;
        private System.Windows.Forms.Button btnHome;
        private System.Windows.Forms.Panel panel1;
        private System.Windows.Forms.Button btnborrowlist;
        private System.Windows.Forms.Panel panel4;
        private System.Windows.Forms.Button btnuserlist;
        private System.Windows.Forms.Panel panel8;
        private System.Windows.Forms.Button btnrecords;
        private System.Windows.Forms.Panel panel9;
        private System.Windows.Forms.Button btninven;
        private System.Windows.Forms.Panel panel11;
        private System.Windows.Forms.Button button2;
        private System.Windows.Forms.Panel panel5;
        private System.Windows.Forms.Button button1;
        private System.Windows.Forms.Timer sidebarTimer;
    }
}