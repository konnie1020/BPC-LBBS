﻿namespace LBBS_system
{
    partial class userhistory
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            System.ComponentModel.ComponentResourceManager resources = new System.ComponentModel.ComponentResourceManager(typeof(userhistory));
            this.flpMenu = new System.Windows.Forms.FlowLayoutPanel();
            this.panel2 = new System.Windows.Forms.Panel();
            this.menubtn = new System.Windows.Forms.PictureBox();
            this.label3 = new System.Windows.Forms.Label();
            this.panel3 = new System.Windows.Forms.Panel();
            this.btnHome = new System.Windows.Forms.Button();
            this.panel1 = new System.Windows.Forms.Panel();
            this.btnborrowlist = new System.Windows.Forms.Button();
            this.panel8 = new System.Windows.Forms.Panel();
            this.btnrecords = new System.Windows.Forms.Button();
            this.panel9 = new System.Windows.Forms.Panel();
            this.btninven = new System.Windows.Forms.Button();
            this.dataGridView1 = new System.Windows.Forms.DataGridView();
            this.panel11 = new System.Windows.Forms.Panel();
            this.button2 = new System.Windows.Forms.Button();
            this.flpMenu.SuspendLayout();
            this.panel2.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.menubtn)).BeginInit();
            this.panel3.SuspendLayout();
            this.panel1.SuspendLayout();
            this.panel8.SuspendLayout();
            this.panel9.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.dataGridView1)).BeginInit();
            this.panel11.SuspendLayout();
            this.SuspendLayout();
            // 
            // flpMenu
            // 
            this.flpMenu.BackColor = System.Drawing.Color.ForestGreen;
            this.flpMenu.Controls.Add(this.panel2);
            this.flpMenu.Controls.Add(this.panel3);
            this.flpMenu.Controls.Add(this.panel1);
            this.flpMenu.Controls.Add(this.panel8);
            this.flpMenu.Controls.Add(this.panel9);
            this.flpMenu.Controls.Add(this.panel11);
            this.flpMenu.Dock = System.Windows.Forms.DockStyle.Left;
            this.flpMenu.Location = new System.Drawing.Point(0, 0);
            this.flpMenu.Margin = new System.Windows.Forms.Padding(4);
            this.flpMenu.MaximumSize = new System.Drawing.Size(336, 692);
            this.flpMenu.MinimumSize = new System.Drawing.Size(91, 690);
            this.flpMenu.Name = "flpMenu";
            this.flpMenu.Size = new System.Drawing.Size(258, 690);
            this.flpMenu.TabIndex = 33;
            this.flpMenu.Paint += new System.Windows.Forms.PaintEventHandler(this.flpMenu_Paint);
            // 
            // panel2
            // 
            this.panel2.Controls.Add(this.menubtn);
            this.panel2.Controls.Add(this.label3);
            this.panel2.Location = new System.Drawing.Point(4, 4);
            this.panel2.Margin = new System.Windows.Forms.Padding(4);
            this.panel2.Name = "panel2";
            this.panel2.Size = new System.Drawing.Size(332, 127);
            this.panel2.TabIndex = 2;
            // 
            // menubtn
            // 
            this.menubtn.Cursor = System.Windows.Forms.Cursors.Hand;
            this.menubtn.Image = ((System.Drawing.Image)(resources.GetObject("menubtn.Image")));
            this.menubtn.Location = new System.Drawing.Point(12, 33);
            this.menubtn.Margin = new System.Windows.Forms.Padding(4);
            this.menubtn.Name = "menubtn";
            this.menubtn.Size = new System.Drawing.Size(67, 49);
            this.menubtn.SizeMode = System.Windows.Forms.PictureBoxSizeMode.StretchImage;
            this.menubtn.TabIndex = 1;
            this.menubtn.TabStop = false;
            // 
            // label3
            // 
            this.label3.AutoSize = true;
            this.label3.Font = new System.Drawing.Font("Segoe UI", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label3.ForeColor = System.Drawing.Color.White;
            this.label3.Location = new System.Drawing.Point(87, 46);
            this.label3.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.label3.Name = "label3";
            this.label3.Size = new System.Drawing.Size(69, 28);
            this.label3.TabIndex = 1;
            this.label3.Text = "MENU";
            // 
            // panel3
            // 
            this.panel3.Controls.Add(this.btnHome);
            this.panel3.Location = new System.Drawing.Point(4, 139);
            this.panel3.Margin = new System.Windows.Forms.Padding(4);
            this.panel3.Name = "panel3";
            this.panel3.Size = new System.Drawing.Size(332, 52);
            this.panel3.TabIndex = 3;
            // 
            // btnHome
            // 
            this.btnHome.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.btnHome.Font = new System.Drawing.Font("Segoe UI", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btnHome.ForeColor = System.Drawing.Color.White;
            this.btnHome.ImageAlign = System.Drawing.ContentAlignment.MiddleLeft;
            this.btnHome.Location = new System.Drawing.Point(-5, -18);
            this.btnHome.Margin = new System.Windows.Forms.Padding(4);
            this.btnHome.Name = "btnHome";
            this.btnHome.Size = new System.Drawing.Size(367, 89);
            this.btnHome.TabIndex = 2;
            this.btnHome.Text = "                Home";
            this.btnHome.TextAlign = System.Drawing.ContentAlignment.MiddleLeft;
            this.btnHome.UseVisualStyleBackColor = true;
            this.btnHome.Click += new System.EventHandler(this.btnHome_Click);
            // 
            // panel1
            // 
            this.panel1.Controls.Add(this.btnborrowlist);
            this.panel1.Location = new System.Drawing.Point(4, 199);
            this.panel1.Margin = new System.Windows.Forms.Padding(4);
            this.panel1.Name = "panel1";
            this.panel1.Size = new System.Drawing.Size(332, 52);
            this.panel1.TabIndex = 1;
            // 
            // btnborrowlist
            // 
            this.btnborrowlist.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.btnborrowlist.Font = new System.Drawing.Font("Segoe UI", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btnborrowlist.ForeColor = System.Drawing.Color.White;
            this.btnborrowlist.ImageAlign = System.Drawing.ContentAlignment.MiddleLeft;
            this.btnborrowlist.Location = new System.Drawing.Point(-7, -18);
            this.btnborrowlist.Margin = new System.Windows.Forms.Padding(4);
            this.btnborrowlist.Name = "btnborrowlist";
            this.btnborrowlist.Size = new System.Drawing.Size(367, 89);
            this.btnborrowlist.TabIndex = 2;
            this.btnborrowlist.Text = "                Borrower List";
            this.btnborrowlist.TextAlign = System.Drawing.ContentAlignment.MiddleLeft;
            this.btnborrowlist.UseVisualStyleBackColor = true;
            this.btnborrowlist.Click += new System.EventHandler(this.btnborrowlist_Click);
            // 
            // panel8
            // 
            this.panel8.Controls.Add(this.btnrecords);
            this.panel8.Location = new System.Drawing.Point(4, 259);
            this.panel8.Margin = new System.Windows.Forms.Padding(4);
            this.panel8.Name = "panel8";
            this.panel8.Size = new System.Drawing.Size(332, 52);
            this.panel8.TabIndex = 8;
            // 
            // btnrecords
            // 
            this.btnrecords.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.btnrecords.Font = new System.Drawing.Font("Segoe UI", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btnrecords.ForeColor = System.Drawing.Color.White;
            this.btnrecords.ImageAlign = System.Drawing.ContentAlignment.MiddleLeft;
            this.btnrecords.Location = new System.Drawing.Point(-4, -16);
            this.btnrecords.Margin = new System.Windows.Forms.Padding(4);
            this.btnrecords.Name = "btnrecords";
            this.btnrecords.Size = new System.Drawing.Size(367, 89);
            this.btnrecords.TabIndex = 2;
            this.btnrecords.Text = "                Records\r\n\r\n";
            this.btnrecords.TextAlign = System.Drawing.ContentAlignment.MiddleLeft;
            this.btnrecords.UseVisualStyleBackColor = true;
            this.btnrecords.Click += new System.EventHandler(this.btnrecords_Click);
            // 
            // panel9
            // 
            this.panel9.Controls.Add(this.btninven);
            this.panel9.Location = new System.Drawing.Point(4, 319);
            this.panel9.Margin = new System.Windows.Forms.Padding(4);
            this.panel9.Name = "panel9";
            this.panel9.Size = new System.Drawing.Size(332, 52);
            this.panel9.TabIndex = 9;
            // 
            // btninven
            // 
            this.btninven.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.btninven.Font = new System.Drawing.Font("Segoe UI", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btninven.ForeColor = System.Drawing.Color.White;
            this.btninven.ImageAlign = System.Drawing.ContentAlignment.MiddleLeft;
            this.btninven.Location = new System.Drawing.Point(-4, -18);
            this.btninven.Margin = new System.Windows.Forms.Padding(4);
            this.btninven.Name = "btninven";
            this.btninven.Size = new System.Drawing.Size(367, 89);
            this.btninven.TabIndex = 2;
            this.btninven.Text = "                Inventory";
            this.btninven.TextAlign = System.Drawing.ContentAlignment.MiddleLeft;
            this.btninven.UseVisualStyleBackColor = true;
            this.btninven.Click += new System.EventHandler(this.btninven_Click);
            // 
            // dataGridView1
            // 
            this.dataGridView1.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            this.dataGridView1.Location = new System.Drawing.Point(287, 4);
            this.dataGridView1.Margin = new System.Windows.Forms.Padding(3, 2, 3, 2);
            this.dataGridView1.Name = "dataGridView1";
            this.dataGridView1.RowTemplate.Height = 24;
            this.dataGridView1.Size = new System.Drawing.Size(1156, 654);
            this.dataGridView1.TabIndex = 23;
            // 
            // panel11
            // 
            this.panel11.Controls.Add(this.button2);
            this.panel11.Location = new System.Drawing.Point(4, 379);
            this.panel11.Margin = new System.Windows.Forms.Padding(4);
            this.panel11.Name = "panel11";
            this.panel11.Size = new System.Drawing.Size(332, 52);
            this.panel11.TabIndex = 29;
            // 
            // button2
            // 
            this.button2.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.button2.Font = new System.Drawing.Font("Segoe UI", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.button2.ForeColor = System.Drawing.Color.White;
            this.button2.ImageAlign = System.Drawing.ContentAlignment.MiddleLeft;
            this.button2.Location = new System.Drawing.Point(-1, -16);
            this.button2.Margin = new System.Windows.Forms.Padding(4);
            this.button2.Name = "button2";
            this.button2.Size = new System.Drawing.Size(367, 89);
            this.button2.TabIndex = 2;
            this.button2.Text = "                Log Out";
            this.button2.TextAlign = System.Drawing.ContentAlignment.MiddleLeft;
            this.button2.UseVisualStyleBackColor = true;
            this.button2.Click += new System.EventHandler(this.button2_Click);
            // 
            // userhistory
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(8F, 16F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.BackColor = System.Drawing.Color.DarkGreen;
            this.ClientSize = new System.Drawing.Size(1786, 672);
            this.Controls.Add(this.flpMenu);
            this.Controls.Add(this.dataGridView1);
            this.Margin = new System.Windows.Forms.Padding(3, 2, 3, 2);
            this.Name = "userhistory";
            this.Text = "Records";
            this.Load += new System.EventHandler(this.Records_Load);
            this.flpMenu.ResumeLayout(false);
            this.panel2.ResumeLayout(false);
            this.panel2.PerformLayout();
            ((System.ComponentModel.ISupportInitialize)(this.menubtn)).EndInit();
            this.panel3.ResumeLayout(false);
            this.panel1.ResumeLayout(false);
            this.panel8.ResumeLayout(false);
            this.panel9.ResumeLayout(false);
            ((System.ComponentModel.ISupportInitialize)(this.dataGridView1)).EndInit();
            this.panel11.ResumeLayout(false);
            this.ResumeLayout(false);

        }

        #endregion

        private System.Windows.Forms.FlowLayoutPanel flpMenu;
        private System.Windows.Forms.Panel panel2;
        private System.Windows.Forms.PictureBox menubtn;
        private System.Windows.Forms.Label label3;
        private System.Windows.Forms.Panel panel3;
        private System.Windows.Forms.Button btnHome;
        private System.Windows.Forms.Panel panel1;
        private System.Windows.Forms.Button btnborrowlist;
        private System.Windows.Forms.Panel panel8;
        private System.Windows.Forms.Button btnrecords;
        private System.Windows.Forms.Panel panel9;
        private System.Windows.Forms.Button btninven;
        private System.Windows.Forms.DataGridView dataGridView1;
        private System.Windows.Forms.Panel panel11;
        private System.Windows.Forms.Button button2;
    }
}