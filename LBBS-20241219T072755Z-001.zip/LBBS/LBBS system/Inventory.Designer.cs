﻿namespace LBBS_system
{
    partial class Inventory
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            System.ComponentModel.ComponentResourceManager resources = new System.ComponentModel.ComponentResourceManager(typeof(Inventory));
            this.label2 = new System.Windows.Forms.Label();
            this.tbtitle = new System.Windows.Forms.TextBox();
            this.label1 = new System.Windows.Forms.Label();
            this.tbid = new System.Windows.Forms.TextBox();
            this.dataGridView1 = new System.Windows.Forms.DataGridView();
            this.btnremove = new System.Windows.Forms.Button();
            this.btnadd = new System.Windows.Forms.Button();
            this.pictureBox1 = new System.Windows.Forms.PictureBox();
            this.quintity = new System.Windows.Forms.Label();
            this.tbquan = new System.Windows.Forms.TextBox();
            this.flpMenu = new System.Windows.Forms.FlowLayoutPanel();
            this.panel2 = new System.Windows.Forms.Panel();
            this.menubtn = new System.Windows.Forms.PictureBox();
            this.label3 = new System.Windows.Forms.Label();
            this.panel3 = new System.Windows.Forms.Panel();
            this.btnHome = new System.Windows.Forms.Button();
            this.panel1 = new System.Windows.Forms.Panel();
            this.btnborrowlist = new System.Windows.Forms.Button();
            this.panel4 = new System.Windows.Forms.Panel();
            this.btnuserlist = new System.Windows.Forms.Button();
            this.panel8 = new System.Windows.Forms.Panel();
            this.btnrecords = new System.Windows.Forms.Button();
            this.panel9 = new System.Windows.Forms.Panel();
            this.btninven = new System.Windows.Forms.Button();
            this.panel11 = new System.Windows.Forms.Panel();
            this.button2 = new System.Windows.Forms.Button();
            ((System.ComponentModel.ISupportInitialize)(this.dataGridView1)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox1)).BeginInit();
            this.flpMenu.SuspendLayout();
            this.panel2.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.menubtn)).BeginInit();
            this.panel3.SuspendLayout();
            this.panel1.SuspendLayout();
            this.panel4.SuspendLayout();
            this.panel8.SuspendLayout();
            this.panel9.SuspendLayout();
            this.panel11.SuspendLayout();
            this.SuspendLayout();
            // 
            // label2
            // 
            this.label2.AutoSize = true;
            this.label2.Font = new System.Drawing.Font("Segoe UI", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label2.ForeColor = System.Drawing.Color.White;
            this.label2.Location = new System.Drawing.Point(265, 369);
            this.label2.Name = "label2";
            this.label2.Size = new System.Drawing.Size(103, 28);
            this.label2.TabIndex = 16;
            this.label2.Text = "Book Title:";
            // 
            // tbtitle
            // 
            this.tbtitle.Location = new System.Drawing.Point(377, 369);
            this.tbtitle.Margin = new System.Windows.Forms.Padding(3, 2, 3, 2);
            this.tbtitle.Name = "tbtitle";
            this.tbtitle.Size = new System.Drawing.Size(243, 22);
            this.tbtitle.TabIndex = 15;
            // 
            // label1
            // 
            this.label1.AutoSize = true;
            this.label1.Font = new System.Drawing.Font("Segoe UI", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label1.ForeColor = System.Drawing.Color.White;
            this.label1.Location = new System.Drawing.Point(288, 330);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(80, 28);
            this.label1.TabIndex = 14;
            this.label1.Text = "BookID:";
            // 
            // tbid
            // 
            this.tbid.Location = new System.Drawing.Point(377, 330);
            this.tbid.Margin = new System.Windows.Forms.Padding(3, 2, 3, 2);
            this.tbid.Name = "tbid";
            this.tbid.Size = new System.Drawing.Size(243, 22);
            this.tbid.TabIndex = 13;
            // 
            // dataGridView1
            // 
            this.dataGridView1.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            this.dataGridView1.Location = new System.Drawing.Point(659, 37);
            this.dataGridView1.Margin = new System.Windows.Forms.Padding(3, 2, 3, 2);
            this.dataGridView1.Name = "dataGridView1";
            this.dataGridView1.RowTemplate.Height = 24;
            this.dataGridView1.Size = new System.Drawing.Size(803, 663);
            this.dataGridView1.TabIndex = 12;
            this.dataGridView1.CellClick += new System.Windows.Forms.DataGridViewCellEventHandler(this.dataGridView1_CellClick);
            
            // 
            // btnremove
            // 
            this.btnremove.BackColor = System.Drawing.Color.Yellow;
            this.btnremove.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.btnremove.Font = new System.Drawing.Font("Segoe UI", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btnremove.Location = new System.Drawing.Point(507, 478);
            this.btnremove.Margin = new System.Windows.Forms.Padding(3, 2, 3, 2);
            this.btnremove.Name = "btnremove";
            this.btnremove.Size = new System.Drawing.Size(147, 59);
            this.btnremove.TabIndex = 19;
            this.btnremove.Text = "Remove";
            this.btnremove.UseVisualStyleBackColor = false;
            this.btnremove.Click += new System.EventHandler(this.btnremove_Click);
            // 
            // btnadd
            // 
            this.btnadd.BackColor = System.Drawing.Color.Yellow;
            this.btnadd.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.btnadd.Font = new System.Drawing.Font("Segoe UI", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btnadd.Location = new System.Drawing.Point(287, 478);
            this.btnadd.Margin = new System.Windows.Forms.Padding(3, 2, 3, 2);
            this.btnadd.Name = "btnadd";
            this.btnadd.Size = new System.Drawing.Size(147, 59);
            this.btnadd.TabIndex = 18;
            this.btnadd.Text = "Add";
            this.btnadd.UseVisualStyleBackColor = false;
            this.btnadd.Click += new System.EventHandler(this.btnadd_Click);
            // 
            // pictureBox1
            // 
            this.pictureBox1.Image = global::LBBS_system.Properties.Resources.lbbs_no_bg;
            this.pictureBox1.Location = new System.Drawing.Point(281, 37);
            this.pictureBox1.Margin = new System.Windows.Forms.Padding(4);
            this.pictureBox1.Name = "pictureBox1";
            this.pictureBox1.Size = new System.Drawing.Size(355, 260);
            this.pictureBox1.SizeMode = System.Windows.Forms.PictureBoxSizeMode.StretchImage;
            this.pictureBox1.TabIndex = 17;
            this.pictureBox1.TabStop = false;
            // 
            // quintity
            // 
            this.quintity.AutoSize = true;
            this.quintity.Font = new System.Drawing.Font("Segoe UI", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.quintity.ForeColor = System.Drawing.Color.White;
            this.quintity.Location = new System.Drawing.Point(265, 410);
            this.quintity.Name = "quintity";
            this.quintity.Size = new System.Drawing.Size(89, 28);
            this.quintity.TabIndex = 21;
            this.quintity.Text = "quantity:";
            // 
            // tbquan
            // 
            this.tbquan.Location = new System.Drawing.Point(377, 410);
            this.tbquan.Margin = new System.Windows.Forms.Padding(3, 2, 3, 2);
            this.tbquan.Name = "tbquan";
            this.tbquan.Size = new System.Drawing.Size(243, 22);
            this.tbquan.TabIndex = 20;
            // 
            // flpMenu
            // 
            this.flpMenu.BackColor = System.Drawing.Color.ForestGreen;
            this.flpMenu.Controls.Add(this.panel2);
            this.flpMenu.Controls.Add(this.panel3);
            this.flpMenu.Controls.Add(this.panel1);
            this.flpMenu.Controls.Add(this.panel4);
            this.flpMenu.Controls.Add(this.panel8);
            this.flpMenu.Controls.Add(this.panel9);
            this.flpMenu.Controls.Add(this.panel11);
            this.flpMenu.Dock = System.Windows.Forms.DockStyle.Left;
            this.flpMenu.Location = new System.Drawing.Point(0, 0);
            this.flpMenu.Margin = new System.Windows.Forms.Padding(4);
            this.flpMenu.MaximumSize = new System.Drawing.Size(336, 692);
            this.flpMenu.MinimumSize = new System.Drawing.Size(91, 690);
            this.flpMenu.Name = "flpMenu";
            this.flpMenu.Size = new System.Drawing.Size(253, 690);
            this.flpMenu.TabIndex = 22;
            this.flpMenu.Paint += new System.Windows.Forms.PaintEventHandler(this.flpMenu_Paint);
            // 
            // panel2
            // 
            this.panel2.Controls.Add(this.menubtn);
            this.panel2.Controls.Add(this.label3);
            this.panel2.Location = new System.Drawing.Point(4, 4);
            this.panel2.Margin = new System.Windows.Forms.Padding(4);
            this.panel2.Name = "panel2";
            this.panel2.Size = new System.Drawing.Size(332, 127);
            this.panel2.TabIndex = 2;
            // 
            // menubtn
            // 
            this.menubtn.Cursor = System.Windows.Forms.Cursors.Hand;
            this.menubtn.Image = ((System.Drawing.Image)(resources.GetObject("menubtn.Image")));
            this.menubtn.Location = new System.Drawing.Point(12, 33);
            this.menubtn.Margin = new System.Windows.Forms.Padding(4);
            this.menubtn.Name = "menubtn";
            this.menubtn.Size = new System.Drawing.Size(67, 49);
            this.menubtn.SizeMode = System.Windows.Forms.PictureBoxSizeMode.StretchImage;
            this.menubtn.TabIndex = 1;
            this.menubtn.TabStop = false;
            // 
            // label3
            // 
            this.label3.AutoSize = true;
            this.label3.Font = new System.Drawing.Font("Segoe UI", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label3.ForeColor = System.Drawing.Color.White;
            this.label3.Location = new System.Drawing.Point(87, 46);
            this.label3.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.label3.Name = "label3";
            this.label3.Size = new System.Drawing.Size(69, 28);
            this.label3.TabIndex = 1;
            this.label3.Text = "MENU";
            // 
            // panel3
            // 
            this.panel3.Controls.Add(this.btnHome);
            this.panel3.Location = new System.Drawing.Point(4, 139);
            this.panel3.Margin = new System.Windows.Forms.Padding(4);
            this.panel3.Name = "panel3";
            this.panel3.Size = new System.Drawing.Size(332, 52);
            this.panel3.TabIndex = 3;
            // 
            // btnHome
            // 
            this.btnHome.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.btnHome.Font = new System.Drawing.Font("Segoe UI", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btnHome.ForeColor = System.Drawing.Color.White;
            this.btnHome.ImageAlign = System.Drawing.ContentAlignment.MiddleLeft;
            this.btnHome.Location = new System.Drawing.Point(-5, -18);
            this.btnHome.Margin = new System.Windows.Forms.Padding(4);
            this.btnHome.Name = "btnHome";
            this.btnHome.Size = new System.Drawing.Size(367, 89);
            this.btnHome.TabIndex = 2;
            this.btnHome.Text = "                Home";
            this.btnHome.TextAlign = System.Drawing.ContentAlignment.MiddleLeft;
            this.btnHome.UseVisualStyleBackColor = true;
            this.btnHome.Click += new System.EventHandler(this.btnHome_Click);
            // 
            // panel1
            // 
            this.panel1.Controls.Add(this.btnborrowlist);
            this.panel1.Location = new System.Drawing.Point(4, 199);
            this.panel1.Margin = new System.Windows.Forms.Padding(4);
            this.panel1.Name = "panel1";
            this.panel1.Size = new System.Drawing.Size(332, 52);
            this.panel1.TabIndex = 1;
            // 
            // btnborrowlist
            // 
            this.btnborrowlist.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.btnborrowlist.Font = new System.Drawing.Font("Segoe UI", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btnborrowlist.ForeColor = System.Drawing.Color.White;
            this.btnborrowlist.ImageAlign = System.Drawing.ContentAlignment.MiddleLeft;
            this.btnborrowlist.Location = new System.Drawing.Point(-7, -18);
            this.btnborrowlist.Margin = new System.Windows.Forms.Padding(4);
            this.btnborrowlist.Name = "btnborrowlist";
            this.btnborrowlist.Size = new System.Drawing.Size(367, 89);
            this.btnborrowlist.TabIndex = 2;
            this.btnborrowlist.Text = "                Borrower List";
            this.btnborrowlist.TextAlign = System.Drawing.ContentAlignment.MiddleLeft;
            this.btnborrowlist.UseVisualStyleBackColor = true;
            this.btnborrowlist.Click += new System.EventHandler(this.btnborrowlist_Click);
            // 
            // panel4
            // 
            this.panel4.Controls.Add(this.btnuserlist);
            this.panel4.Location = new System.Drawing.Point(4, 259);
            this.panel4.Margin = new System.Windows.Forms.Padding(4);
            this.panel4.Name = "panel4";
            this.panel4.Size = new System.Drawing.Size(332, 52);
            this.panel4.TabIndex = 3;
            // 
            // btnuserlist
            // 
            this.btnuserlist.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.btnuserlist.Font = new System.Drawing.Font("Segoe UI", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btnuserlist.ForeColor = System.Drawing.Color.White;
            this.btnuserlist.ImageAlign = System.Drawing.ContentAlignment.MiddleLeft;
            this.btnuserlist.Location = new System.Drawing.Point(-5, -18);
            this.btnuserlist.Margin = new System.Windows.Forms.Padding(4);
            this.btnuserlist.Name = "btnuserlist";
            this.btnuserlist.Size = new System.Drawing.Size(367, 89);
            this.btnuserlist.TabIndex = 2;
            this.btnuserlist.Text = "                User List";
            this.btnuserlist.TextAlign = System.Drawing.ContentAlignment.MiddleLeft;
            this.btnuserlist.UseVisualStyleBackColor = true;
            this.btnuserlist.Click += new System.EventHandler(this.btnuserlist_Click);
            // 
            // panel8
            // 
            this.panel8.Controls.Add(this.btnrecords);
            this.panel8.Location = new System.Drawing.Point(4, 319);
            this.panel8.Margin = new System.Windows.Forms.Padding(4);
            this.panel8.Name = "panel8";
            this.panel8.Size = new System.Drawing.Size(332, 52);
            this.panel8.TabIndex = 8;
            // 
            // btnrecords
            // 
            this.btnrecords.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.btnrecords.Font = new System.Drawing.Font("Segoe UI", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btnrecords.ForeColor = System.Drawing.Color.White;
            this.btnrecords.ImageAlign = System.Drawing.ContentAlignment.MiddleLeft;
            this.btnrecords.Location = new System.Drawing.Point(-4, -16);
            this.btnrecords.Margin = new System.Windows.Forms.Padding(4);
            this.btnrecords.Name = "btnrecords";
            this.btnrecords.Size = new System.Drawing.Size(367, 89);
            this.btnrecords.TabIndex = 2;
            this.btnrecords.Text = "                Records\r\n\r\n";
            this.btnrecords.TextAlign = System.Drawing.ContentAlignment.MiddleLeft;
            this.btnrecords.UseVisualStyleBackColor = true;
            this.btnrecords.Click += new System.EventHandler(this.btnrecords_Click);
            // 
            // panel9
            // 
            this.panel9.Controls.Add(this.btninven);
            this.panel9.Location = new System.Drawing.Point(4, 379);
            this.panel9.Margin = new System.Windows.Forms.Padding(4);
            this.panel9.Name = "panel9";
            this.panel9.Size = new System.Drawing.Size(332, 52);
            this.panel9.TabIndex = 9;
            // 
            // btninven
            // 
            this.btninven.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.btninven.Font = new System.Drawing.Font("Segoe UI", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btninven.ForeColor = System.Drawing.Color.White;
            this.btninven.ImageAlign = System.Drawing.ContentAlignment.MiddleLeft;
            this.btninven.Location = new System.Drawing.Point(-5, -32);
            this.btninven.Margin = new System.Windows.Forms.Padding(4);
            this.btninven.Name = "btninven";
            this.btninven.Size = new System.Drawing.Size(367, 89);
            this.btninven.TabIndex = 2;
            this.btninven.Text = "                Inventory";
            this.btninven.TextAlign = System.Drawing.ContentAlignment.MiddleLeft;
            this.btninven.UseVisualStyleBackColor = true;
            this.btninven.Click += new System.EventHandler(this.btninven_Click);
            // 
            // panel11
            // 
            this.panel11.Controls.Add(this.button2);
            this.panel11.Location = new System.Drawing.Point(4, 439);
            this.panel11.Margin = new System.Windows.Forms.Padding(4);
            this.panel11.Name = "panel11";
            this.panel11.Size = new System.Drawing.Size(332, 52);
            this.panel11.TabIndex = 10;
            // 
            // button2
            // 
            this.button2.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.button2.Font = new System.Drawing.Font("Segoe UI", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.button2.ForeColor = System.Drawing.Color.White;
            this.button2.ImageAlign = System.Drawing.ContentAlignment.MiddleLeft;
            this.button2.Location = new System.Drawing.Point(-1, -23);
            this.button2.Margin = new System.Windows.Forms.Padding(4);
            this.button2.Name = "button2";
            this.button2.Size = new System.Drawing.Size(367, 76);
            this.button2.TabIndex = 2;
            this.button2.Text = "                Log Out";
            this.button2.TextAlign = System.Drawing.ContentAlignment.MiddleLeft;
            this.button2.UseVisualStyleBackColor = true;
            this.button2.Click += new System.EventHandler(this.button2_Click);
            // 
            // Inventory
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(8F, 16F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.BackColor = System.Drawing.Color.DarkGreen;
            this.ClientSize = new System.Drawing.Size(1756, 690);
            this.Controls.Add(this.flpMenu);
            this.Controls.Add(this.quintity);
            this.Controls.Add(this.tbquan);
            this.Controls.Add(this.btnremove);
            this.Controls.Add(this.btnadd);
            this.Controls.Add(this.pictureBox1);
            this.Controls.Add(this.label2);
            this.Controls.Add(this.tbtitle);
            this.Controls.Add(this.label1);
            this.Controls.Add(this.tbid);
            this.Controls.Add(this.dataGridView1);
            this.Margin = new System.Windows.Forms.Padding(3, 2, 3, 2);
            this.Name = "Inventory";
            this.Text = "Inventory";
            
            ((System.ComponentModel.ISupportInitialize)(this.dataGridView1)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox1)).EndInit();
            this.flpMenu.ResumeLayout(false);
            this.panel2.ResumeLayout(false);
            this.panel2.PerformLayout();
            ((System.ComponentModel.ISupportInitialize)(this.menubtn)).EndInit();
            this.panel3.ResumeLayout(false);
            this.panel1.ResumeLayout(false);
            this.panel4.ResumeLayout(false);
            this.panel8.ResumeLayout(false);
            this.panel9.ResumeLayout(false);
            this.panel11.ResumeLayout(false);
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.PictureBox pictureBox1;
        private System.Windows.Forms.Label label2;
        private System.Windows.Forms.TextBox tbtitle;
        private System.Windows.Forms.Label label1;
        private System.Windows.Forms.TextBox tbid;
        private System.Windows.Forms.DataGridView dataGridView1;
        private System.Windows.Forms.Button btnremove;
        private System.Windows.Forms.Button btnadd;
        private System.Windows.Forms.Label quintity;
        private System.Windows.Forms.TextBox tbquan;
        private System.Windows.Forms.FlowLayoutPanel flpMenu;
        private System.Windows.Forms.Panel panel2;
        private System.Windows.Forms.PictureBox menubtn;
        private System.Windows.Forms.Label label3;
        private System.Windows.Forms.Panel panel3;
        private System.Windows.Forms.Button btnHome;
        private System.Windows.Forms.Panel panel1;
        private System.Windows.Forms.Button btnborrowlist;
        private System.Windows.Forms.Panel panel4;
        private System.Windows.Forms.Button btnuserlist;
        private System.Windows.Forms.Panel panel8;
        private System.Windows.Forms.Button btnrecords;
        private System.Windows.Forms.Panel panel9;
        private System.Windows.Forms.Button btninven;
        private System.Windows.Forms.Panel panel11;
        private System.Windows.Forms.Button button2;
    }
}