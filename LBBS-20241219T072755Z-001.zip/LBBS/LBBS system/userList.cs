﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using System.Data.OleDb;
using System.IO; // For handling file and memory streams

namespace LBBS_system
{
    public partial class userlist : Form
    {
        private OleDbConnection conn;
        private OleDbCommand cmd;
        private OleDbDataAdapter adapter;
        private DataTable dt;
        private bool isEditing = false; // Track if editing an existing user
        private bool sidebarExpand = false; // Sidebar toggle state
        private bool isAnimating = false; // Prevent animation conflicts

        public userlist()
        {
            InitializeComponent();
            conn = new OleDbConnection(@"Provider=Microsoft.ACE.OLEDB.12.0;Data Source=LBBS.accdb");
        }

        private void tbid_TextChanged(object sender, EventArgs e)
        {

        }

        private void tbln_TextChanged(object sender, EventArgs e)
        {

        }

        private void ttbfn_TextChanged(object sender, EventArgs e)
        {

        }

        private void tbemail_TextChanged(object sender, EventArgs e)
        {

        }

        private void tbbid_TextChanged(object sender, EventArgs e)
        {

        }

        private void dgv_CellContentClick(object sender, DataGridViewCellEventArgs e)
        {
            

        }

        private void btnadd_Click(object sender, EventArgs e)
        {
            if (isEditing)
            {
                UpdateUser();
            }
            else
            {
                AddUser();
            }
        }

        private void AddUser()
        {
            try
            {
                if (string.IsNullOrWhiteSpace(tbuser.Text) || string.IsNullOrWhiteSpace(tbln.Text))
                {
                    MessageBox.Show("User ID and Last Name cannot be empty.");
                    return;
                }

                conn.Open();
                string query = "INSERT INTO UserList ([Username], [Lastname], [Firstname], [Email], [Position]) VALUES " +
                               " (@UserName, @lastName, @firstName, @Email, @Position)";
                cmd = new OleDbCommand(query, conn);
                cmd.Parameters.AddWithValue("@UserName", tbuser.Text);
               
                cmd.Parameters.AddWithValue("@lastName", tbln.Text);
                cmd.Parameters.AddWithValue("@firstName", ttbfn.Text);
                cmd.Parameters.AddWithValue("@Email", tbemail.Text);
                cmd.Parameters.AddWithValue("@Position", tbpos.Text);

                cmd.ExecuteNonQuery();
                conn.Close();

                MessageBox.Show("User added successfully!");
                ClearFields();
                LoadData();
            }
            catch (Exception ex)
            {
                MessageBox.Show("Error: " + ex.Message);
                conn.Close();
            }
        }

        private void UpdateUser()
        {
            try
            {
                conn.Open();
                string query = "UPDATE UserList SET Username=@UserName LastName=@lastName, FirstName=@firstName, Email=@Email, Position=@Position " +
                               "WHERE ID=@userID";
                cmd = new OleDbCommand(query, conn);

                cmd.Parameters.AddWithValue("@UserName", tbln.Text);
                cmd.Parameters.AddWithValue("@lastName", tbln.Text);
                cmd.Parameters.AddWithValue("@firstName", ttbfn.Text);
                cmd.Parameters.AddWithValue("@Email", tbemail.Text);
                cmd.Parameters.AddWithValue("@Psition", tbpos.Text);
                cmd.Parameters.AddWithValue("@userID", tbid.Text);

                cmd.ExecuteNonQuery();
                conn.Close();

                MessageBox.Show("User updated successfully!");
                ClearFields();
                LoadData();
            }
            catch (Exception ex)
            {
                MessageBox.Show("Error: " + ex.Message);
                conn.Close();
            }
        }

        private void btnedit_Click(object sender, EventArgs e)
        {
            if (string.IsNullOrWhiteSpace(tbid.Text))
            {
                MessageBox.Show("Please select a user to edit.");
                return;
            }

            if (string.IsNullOrWhiteSpace(tbuser.Text) ||
                string.IsNullOrWhiteSpace(tbln.Text) ||
                string.IsNullOrWhiteSpace(ttbfn.Text) ||
                string.IsNullOrWhiteSpace(tbemail.Text) ||
                string.IsNullOrWhiteSpace(tbpos.Text))
            {
                MessageBox.Show("Please fill in all fields before updating.");
                return;
            }

            try
            {
                conn.Open();
                string query = "UPDATE UserList SET [Username]=@us, [Lastname]=@ln, [Firstname]=@fn, [Email]=@em, [Position]=@pos WHERE [ID]=@id";
                cmd = new OleDbCommand(query, conn);

                cmd.Parameters.AddWithValue("@us", tbuser.Text);
                cmd.Parameters.AddWithValue("@ln", tbln.Text);
                cmd.Parameters.AddWithValue("@fn", ttbfn.Text);
                cmd.Parameters.AddWithValue("@em", tbemail.Text);
                cmd.Parameters.AddWithValue("@pos", tbpos.Text);
                cmd.Parameters.AddWithValue("@id", tbid.Text); // Ensure correct ID is used in the WHERE clause

                // Log query for debugging
                MessageBox.Show("Query: " + query);
                MessageBox.Show("Parameters: " +
                                "\nUsername: " + tbuser.Text +
                                "\nLastName: " + tbln.Text +
                                "\nFirstName: " + ttbfn.Text +
                                "\nEmail: " + tbemail.Text +
                                "\nPosition: " + tbpos.Text +
                                "\nID: " + tbid.Text);

                cmd.ExecuteNonQuery();
                conn.Close();

                MessageBox.Show("User updated successfully!");
                ClearFields();
                LoadData();
            }
            catch (Exception ex)
            {
                MessageBox.Show("Error: " + ex.Message);
                conn.Close();
            }
        }

        private void btndel_Click(object sender, EventArgs e)
        {
            if (string.IsNullOrEmpty(tbid.Text))
            {
                MessageBox.Show("Please select a user to delete.");
                return;
            }

            try
            {
                conn.Open();
                string query = "DELETE FROM UserList WHERE UserID=@userID";
                cmd = new OleDbCommand(query, conn);
                cmd.Parameters.AddWithValue("@userID",Convert.ToInt32(tbid.Text));

                int result = cmd.ExecuteNonQuery();
                conn.Close();

                if (result > 0)
                {
                    MessageBox.Show("User deleted successfully!");
                }
                else
                {
                    MessageBox.Show("User not found or could not be deleted.");
                }

                ClearFields();
                LoadData();
            }
            catch (Exception ex)
            {
                MessageBox.Show("Error: " + ex.Message);
                conn.Close();
            }
        }

        private void userlist_Load(object sender, EventArgs e)
        {
            LoadData();
        }

        private void LoadData()
        {
            try
            {
                conn.Open();
                adapter = new OleDbDataAdapter("SELECT * FROM UserList", conn);
                dt = new DataTable();
                adapter.Fill(dt);
                dgv.DataSource = dt; // Assuming dgvUserList is the DataGridView
                conn.Close();
            }
            catch (Exception ex)
            {
                MessageBox.Show("Error: " + ex.Message);
                conn.Close();
            }
        }

        private void ClearFields()
        {
            tbid.Text = "";
            tbln.Text = "";
            ttbfn.Text = "";
            tbemail.Text = "";
            tbpos.Text = "";
            tbuser.Text = "";
        }


        private void tbuser_TextChanged(object sender, EventArgs e)
        {

        }

        private void btncancel_Click(object sender, EventArgs e)
        {
            ClearFields();
            isEditing = false;
        }

        private void dgv_CellClick(object sender, DataGridViewCellEventArgs e)
        {
            if (e.RowIndex >= 0)
            {
                DataGridViewRow row = dgv.Rows[e.RowIndex];
                tbid.Text = dgv.CurrentRow.Cells[0].Value.ToString();
                tbln.Text = dgv.CurrentRow.Cells[1].Value.ToString();
                ttbfn.Text = dgv.CurrentRow.Cells[2].Value.ToString();
                tbemail.Text = dgv.CurrentRow.Cells[3].Value.ToString();
                tbpos.Text = dgv.CurrentRow.Cells[4].Value.ToString();
                tbuser.Text = dgv.CurrentRow.Cells[5].Value.ToString();
            }
        }

        private void button2_Click(object sender, EventArgs e)
        {
            // Create and show the ForgotPasswordForm when the link is clicked
            login Form1 = new login();
            Form1.Show(); // Opens the new form
            this.Hide(); // Optionally hide the current form (LoginForm)
        }
    }
}
