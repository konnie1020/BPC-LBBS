﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using System.Data.OleDb;

namespace LBBS_system
{
    public partial class borrowerList : Form
    {
        private OleDbConnection conn;
        private OleDbCommand cmd;
        private OleDbDataAdapter adapter;
        private DataTable dt;
        private bool isEditing = false;  // Track if we're editing an existing borrower
        private IFormatProvider borrowerID;
        private IFormatProvider bookID;
        private bool topMenuExpand = false;
        private bool sidebarExpand = false; // Track whether the sidebar is expanded
        private bool isAnimating = false; // Prevent multiple triggers

        public borrowerList()
        {
            InitializeComponent();
            conn = new OleDbConnection(@"Provider=Microsoft.ACE.OLEDB.12.0;Data Source=LBBS.accdb");
        }

        private void borrowerList_Load(object sender, EventArgs e)
        {
            LoadData();
            flpMenu.Width = flpMenu.MinimumSize.Width;
            flpprofile.Width = flpprofile.MinimumSize.Width;
        }

        // Add Button Click (button1)
        private void button1_Click(object sender, EventArgs e)
        {
            if (isEditing)
            {
                UpdateBorrower();
            }
            else
            {
                AddBorrower();
            }
        }

        // Save Button Click (btnsave)
        private void btnsave_Click(object sender, EventArgs e)
        {
            if (isEditing)
            {
                UpdateBorrower();
            }
            else
            {
                AddBorrower();
            }
        }

        // Cancel Button Click (btncancel)
        private void btncancel_Click(object sender, EventArgs e)
        {
            ClearFields();
            isEditing = false;
            btnsave.Enabled = false;
            btncancel.Enabled = false;
        }

        // Edit Button Click (btnedit)
        private void btnedit_Click(object sender, EventArgs e)
        {
            if (string.IsNullOrEmpty(tbid.Text))
            {
                MessageBox.Show("Please select a borrower to edit.");
                return;
            }

            isEditing = true;
            btnsave.Enabled = true;
            btncancel.Enabled = true;
        }

        // Delete Button Click (button3)
        private void button3_Click(object sender, EventArgs e)
        {
            if (string.IsNullOrEmpty(tbid.Text))
            {
                MessageBox.Show("Please select a borrower to delete.");
                return;
            }

            try
            {
                conn.Open();
                string query = "DELETE FROM BorrowerList WHERE StudentID=@StudentID";
                cmd = new OleDbCommand(query, conn);
                cmd.Parameters.AddWithValue("@StudentID", tbid.Text);
                int result = cmd.ExecuteNonQuery();
                conn.Close();

                if (result > 0)
                {
                    MessageBox.Show("Borrower deleted successfully!");
                }
                else
                {
                    MessageBox.Show("Borrower not found or could not be deleted.");
                }

                ClearFields();
                LoadData();
            }
            catch (Exception ex)
            {
                MessageBox.Show("Error: " + ex.Message);
                conn.Close();
            }
        }

        // Add Borrower (Insert into DB)
        private void AddBorrower()
        {
            try
            {
                // Ensure the required fields are not empty
                if (string.IsNullOrWhiteSpace(tbid.Text) || string.IsNullOrWhiteSpace(tbbookid.Text))
                {
                    MessageBox.Show("Borrower ID and Book ID cannot be empty.");
                    return;
                }

                conn.Open();
                string query = "INSERT INTO BorrowerList (StudentID, LastName, FirstName, Email, BookID, Title, DateBorrowed, DueDate) " +
                               "VALUES (@borrowerID, @lastName, @firstName, @email, @bookID, @title, @dateBorrowed, @dueDate)";
                cmd = new OleDbCommand(query, conn);

                // Add parameters
                cmd.Parameters.AddWithValue("@borrowerID", tbid.Text); // Treat StudentID as a string
                cmd.Parameters.AddWithValue("@lastName", tbln.Text);
                cmd.Parameters.AddWithValue("@firstName", tbfn.Text);
                cmd.Parameters.AddWithValue("@email", tbemail.Text);
                cmd.Parameters.AddWithValue("@bookID", tbbookid.Text); // Treat BookID as a string
                cmd.Parameters.AddWithValue("@title", tbtitle.Text);
                cmd.Parameters.AddWithValue("@dateBorrowed", dtptoday.Value);
                cmd.Parameters.AddWithValue("@dueDate", dtpdue.Value);

                cmd.ExecuteNonQuery();
                conn.Close();

                MessageBox.Show("Borrower added successfully!");
                ClearFields();
                LoadData();
            }
            catch (Exception ex)
            {
                MessageBox.Show("Error: " + ex.Message);
                if (conn.State == ConnectionState.Open)
                {
                    conn.Close();
                }
            }
        }

        // Update Borrower (Edit in DB)
        private void UpdateBorrower()
        {
            try
            {
                conn.Open();
                string query = "UPDATE BorrowerList SET LastName=@ln, FirstName=@fn, Email=@em, BookID=@bookID, Title=@title, DateBorrowed=@borrowedDate, DueDate=@dueDate " +
                               "WHERE StudentID=@borrowerID";
                cmd = new OleDbCommand(query, conn);
                cmd.Parameters.AddWithValue("@ln", tbln.Text);
                cmd.Parameters.AddWithValue("@fn", tbfn.Text);
                cmd.Parameters.AddWithValue("@em", tbemail.Text);
                cmd.Parameters.AddWithValue("@bookID", tbbookid.Text);
                cmd.Parameters.AddWithValue("@title", tbtitle.Text);
                cmd.Parameters.AddWithValue("@borrowedDate", dtptoday.Value);
                cmd.Parameters.AddWithValue("@dueDate", dtpdue.Value);
                cmd.Parameters.AddWithValue("@borrowerID", tbid.Text);
                cmd.ExecuteNonQuery();
                conn.Close();
                MessageBox.Show("Borrower updated successfully!");
                ClearFields();
                LoadData();
            }
            catch (Exception ex)
            {
                MessageBox.Show("Error: " + ex.Message);
                conn.Close();
            }
        }

        // Load Data into DataGridView
        private void LoadData()
        {
            try
            {
                conn.Open();
                adapter = new OleDbDataAdapter("SELECT * FROM BorrowerList", conn);
                dt = new DataTable();
                adapter.Fill(dt);
                dgv.DataSource = dt;
                conn.Close();
            }
            catch (Exception ex)
            {
                MessageBox.Show("Error: " + ex.Message);
                conn.Close();
            }
        }

        // Clear TextBox Fields
        private void ClearFields()
        {
            tbid.Text = "";
            tbln.Text = "";
            tbfn.Text = "";
            tbemail.Text = "";
            tbbookid.Text = "";
            tbtitle.Text = "";
            dtptoday.Value = DateTime.Now;
            dtpdue.Value = DateTime.Now.AddDays(7);
        }

        // DataGridView Cell Click to populate fields for editing
        private void dgv_CellContentClick(object sender, DataGridViewCellEventArgs e)
        {
            if (e.RowIndex >= 0)
            {
                DataGridViewRow row = dgv.Rows[e.RowIndex];
                tbid.Text = row.Cells["StudentID"].Value.ToString();
                tbln.Text = row.Cells["LastName"].Value.ToString();
                tbfn.Text = row.Cells["FirstName"].Value.ToString();
                tbemail.Text = row.Cells["Email"].Value.ToString();
                tbbookid.Text = row.Cells["BookID"].Value.ToString();
                tbtitle.Text = row.Cells["Title"].Value.ToString();
                dtptoday.Value = Convert.ToDateTime(row.Cells["DateBorrowed"].Value);
                dtpdue.Value = Convert.ToDateTime(row.Cells["DueDate"].Value);
            }
        }

        // TextChanged Events (Optional handling, can be used for validation or formatting)
        private void tbid_TextChanged(object sender, EventArgs e)
        {
            // Handle changes here if needed
        }

        private void tbln_TextChanged(object sender, EventArgs e)
        {
            // Handle changes here if needed
        }

        private void tbfn_TextChanged(object sender, EventArgs e)
        {
            // Handle changes here if needed
        }

        private void tbemail_TextChanged(object sender, EventArgs e)
        {
            // Handle changes here if needed
        }

        private void tbbookid_TextChanged(object sender, EventArgs e)
        {
            // Handle changes here if needed
        }

        private void tbtitle_TextChanged(object sender, EventArgs e)
        {
            // Handle changes here if needed
        }

        private void dtptoday_ValueChanged(object sender, EventArgs e)
        {
            // Handle changes here if needed
        }

        private void dtpdue_ValueChanged(object sender, EventArgs e)
        {
            // Handle changes here if needed
        }
        private void label1_Click(object sender, EventArgs e)
        {

        }

        private void menubtn_Click(object sender, EventArgs e)
        {
            if (!isAnimating) // Prevent repeated triggering while animating
            {
                isAnimating = true;
                sidebarExpand = !sidebarExpand; // Toggle between expanding and collapsing
                sidemenu.Start(); // Start the animation timer
            }
        }

        private void sidemenu_Tick(object sender, EventArgs e)
        {
            if (sidebarExpand)
            {
                // Expand the sidebar
                flpMenu.Width += 10; // Adjust for speed of expansion
                if (flpMenu.Width >= flpMenu.MaximumSize.Width)
                {
                    flpMenu.Width = flpMenu.MaximumSize.Width; // Snap to max size
                    isAnimating = false; // Stop animation
                    sidemenu.Stop();
                }
            }
            else
            {
                // Collapse the sidebar
                flpMenu.Width -= 10; // Adjust for speed of collapse
                if (flpMenu.Width <= flpMenu.MinimumSize.Width)
                {
                    flpMenu.Width = flpMenu.MinimumSize.Width; // Snap to min size
                    isAnimating = false; // Stop animation
                    sidemenu.Stop();
                }
            }
        }

        private void flpMenu_Paint(object sender, PaintEventArgs e)
        {

        }
    }
}
