﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using System.Data.OleDb;

namespace LBBS_system
{
    public partial class userlist : Form
    {
        private OleDbConnection conn;
        private OleDbCommand cmd;
        private OleDbDataAdapter adapter;
        private DataTable dt;

        public userlist()
        {
            InitializeComponent();
            conn = new OleDbConnection(@"Provider=Microsoft.ACE.OLEDB.12.0;Data Source=LBBS.accdb");
        }

        private void tbid_TextChanged(object sender, EventArgs e)
        {

        }

        private void tbln_TextChanged(object sender, EventArgs e)
        {

        }

        private void ttbfn_TextChanged(object sender, EventArgs e)
        {

        }

        private void tbemail_TextChanged(object sender, EventArgs e)
        {

        }

        private void tbbid_TextChanged(object sender, EventArgs e)
        {

        }

        private void dgv_CellContentClick(object sender, DataGridViewCellEventArgs e)
        {
            // Ensure valid row is selected
            if (e.RowIndex >= 0)
            {
                DataGridViewRow row = dgv.Rows[e.RowIndex];
                tbid.Text = row.Cells["ID"].Value.ToString(); // Fill ID
                tbuser.Text = row.Cells["Username"].Value.ToString(); // Fill Username
                tbln.Text = row.Cells["LastName"].Value.ToString(); // Fill LastName
                ttbfn.Text = row.Cells["FirstName"].Value.ToString(); // Fill FirstName
                tbemail.Text = row.Cells["Email"].Value.ToString(); // Fill Email
                tbpos.Text = row.Cells["Position"].Value.ToString(); // Fill Position
            }
        }

        private void btnadd_Click(object sender, EventArgs e)
        {
            if (string.IsNullOrWhiteSpace(tbuser.Text) ||
         string.IsNullOrWhiteSpace(tbln.Text) ||
         string.IsNullOrWhiteSpace(ttbfn.Text) ||
         string.IsNullOrWhiteSpace(tbemail.Text) ||
         string.IsNullOrWhiteSpace(tbpos.Text))
            {
                MessageBox.Show("Please fill in all fields before adding a user.");
                return;
            }

            try
            {
                conn.Open();
                // Prepare the INSERT query
                string query = "INSERT INTO UserList (Username, Lastname, Firstname, Email, Position) VALUES (@us, @ln, @fn, @em, @pos)";
                cmd = new OleDbCommand(query, conn);

                // Adding parameters
                cmd.Parameters.AddWithValue("@us", tbuser.Text);
                cmd.Parameters.AddWithValue("@ln", tbln.Text);
                cmd.Parameters.AddWithValue("@fn", ttbfn.Text);
                cmd.Parameters.AddWithValue("@em", tbemail.Text);
                cmd.Parameters.AddWithValue("@pos", tbpos.Text);

                // Log query for debugging
                MessageBox.Show("Query: " + query);
                MessageBox.Show("Parameters: " +
                                "\nUsername: " + tbuser.Text +
                                "\nLastname: " + tbln.Text +
                                "\nFirstname: " + ttbfn.Text +
                                "\nEmail: " + tbemail.Text +
                                "\nPosition: " + tbpos.Text);

                // Execute the command
                cmd.ExecuteNonQuery();
                conn.Close();

                MessageBox.Show("User added successfully!");
                ClearFields();
                LoadData();
            }
            catch (Exception ex)
            {
                MessageBox.Show("Error: " + ex.Message);
                conn.Close();
            }
        }

        private void btnedit_Click(object sender, EventArgs e)
        {
            if (string.IsNullOrWhiteSpace(tbid.Text))
            {
                MessageBox.Show("Please select a user to edit.");
                return;
            }

            if (string.IsNullOrWhiteSpace(tbuser.Text) ||
                string.IsNullOrWhiteSpace(tbln.Text) ||
                string.IsNullOrWhiteSpace(ttbfn.Text) ||
                string.IsNullOrWhiteSpace(tbemail.Text) ||
                string.IsNullOrWhiteSpace(tbpos.Text))
            {
                MessageBox.Show("Please fill in all fields before updating.");
                return;
            }

            try
            {
                conn.Open();
                string query = "UPDATE UserList SET Username=@us, Lastname=@ln, Firstname=@fn, Email=@em, Position=@pos WHERE ID=@id";
                cmd = new OleDbCommand(query, conn);

                cmd.Parameters.AddWithValue("@us", tbuser.Text);
                cmd.Parameters.AddWithValue("@ln", tbln.Text);
                cmd.Parameters.AddWithValue("@fn", ttbfn.Text);
                cmd.Parameters.AddWithValue("@em", tbemail.Text);
                cmd.Parameters.AddWithValue("@pos", tbpos.Text);
                cmd.Parameters.AddWithValue("@id", tbid.Text); // Ensure correct ID is used in the WHERE clause

                // Log query for debugging
                MessageBox.Show("Query: " + query);
                MessageBox.Show("Parameters: " +
                                "\nUsername: " + tbuser.Text +
                                "\nLastName: " + tbln.Text +
                                "\nFirstName: " + ttbfn.Text +
                                "\nEmail: " + tbemail.Text +
                                "\nPosition: " + tbpos.Text +
                                "\nID: " + tbid.Text);

                cmd.ExecuteNonQuery();
                conn.Close();

                MessageBox.Show("User updated successfully!");
                ClearFields();
                LoadData();
            }
            catch (Exception ex)
            {
                MessageBox.Show("Error: " + ex.Message);
                conn.Close();
            }
        }

        private void btndel_Click(object sender, EventArgs e)
        {
            if (string.IsNullOrWhiteSpace(tbid.Text))  // Ensure ID is selected
            {
                MessageBox.Show("Please select a user to delete.");
                return;
            }

            try
            {
                conn.Open();
                string query = "DELETE FROM UserList WHERE ID = ?";
                cmd = new OleDbCommand(query, conn);
                cmd.Parameters.Add("ID", OleDbType.Integer).Value = int.Parse(tbid.Text);  // Use ID as integer for the query

                int rowsAffected = cmd.ExecuteNonQuery();
                if (rowsAffected > 0)
                {
                    MessageBox.Show("User deleted successfully!");
                }
                else
                {
                    MessageBox.Show("No user was found with the given ID.");
                }
            }
            catch (Exception ex)
            {
                MessageBox.Show("Error: " + ex.Message);
            }
            finally
            {
                conn.Close();
                ClearFields();
                LoadData();
            }
        }

        private void userlist_Load(object sender, EventArgs e)
        {
            LoadData();
        }

        private void LoadData()
        {
            try
            {
                conn.Open();
                adapter = new OleDbDataAdapter("SELECT * FROM UserList", conn);
                dt = new DataTable();
                adapter.Fill(dt);
                dgv.DataSource = dt;
            }
            catch (Exception ex)
            {
                MessageBox.Show("Error loading data: " + ex.Message);
            }
            finally
            {
                conn.Close();
            }
        }

        private void ClearFields()
        {
            tbuser.Clear();
            tbid.Clear();
            tbln.Clear();
            ttbfn.Clear();
            tbemail.Clear();
            tbpos.Clear();
        }

        private void tbuser_TextChanged(object sender, EventArgs e)
        {

        }
    }
}
