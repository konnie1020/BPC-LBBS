﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using System.Data.OleDb;

namespace LBBS_system
{
    public partial class Inventory : Form
    {
        private OleDbConnection conn;
        public Inventory()
        {
            InitializeComponent();
            conn = new OleDbConnection(@"Provider=Microsoft.ACE.OLEDB.12.0;Data Source=LBBS.accdb");
            LoadData();

        }
        private void LoadData()
        {
            try
            {
                conn.Open();
                string query = "SELECT * FROM Books"; // Adjust according to your table name
                OleDbDataAdapter adapter = new OleDbDataAdapter(query, conn); // Fetch data from the database
                DataTable dt = new DataTable(); // Create a DataTable to hold the data
                adapter.Fill(dt); // Fill the DataTable with data from the database

                dataGridView1.DataSource = dt; // Bind the data to your DataGridView
            }
            catch (Exception ex)
            {
                MessageBox.Show("Error loading data: " + ex.Message);
            }
            finally
            {
                conn.Close();
            }
        }

        private bool IsDuplicateBook(string title)
        {
            try
            {
                conn.Open();
                string query = "SELECT COUNT(*) FROM Books WHERE Title = @Title";
                OleDbCommand cmd = new OleDbCommand(query, conn);
                cmd.Parameters.AddWithValue("@Title", title);

                int count = Convert.ToInt32(cmd.ExecuteScalar()); // Get the count of books with the same title
                return count > 0; // If more than 0, then it's a duplicate
            }
            catch (Exception ex)
            {
                MessageBox.Show("Error checking for duplicates: " + ex.Message);
                return false;
            }
            finally
            {
                conn.Close();
            }
        }

        private void numericUpDown1_ValueChanged(object sender, EventArgs e)
        {

        }
        

        private void btnadd_Click(object sender, EventArgs e)
        {
            if (string.IsNullOrWhiteSpace(tbtitle.Text) || string.IsNullOrWhiteSpace(tbquan.Text))
            {
                MessageBox.Show("Please fill in all fields.");
                return;
            }

            if (IsDuplicateBook(tbtitle.Text))  // Check for duplicate book title
            {
                MessageBox.Show("This book already exists.");
                return;
            }

            try
            {
                conn.Open();
                string query = "INSERT INTO Books (Title, Quantity) VALUES (@Title, @Quantity)";
                OleDbCommand cmd = new OleDbCommand(query, conn);
                cmd.Parameters.AddWithValue("@Title", tbtitle.Text);
                cmd.Parameters.AddWithValue("@Quantity", tbquan.Text);

                cmd.ExecuteNonQuery(); // Insert the new book into the database
                MessageBox.Show("Book added successfully!");

                LoadData();  // Reload the DataGridView with updated data
                ClearFields();  // Clear input fields after adding a book

                tbtitle.Focus();  // Focus on the title textbox for the next entry
            }
            catch (Exception ex)
            {
                MessageBox.Show("Error adding book: " + ex.Message);
            }
            finally
            {
                conn.Close();
            }

        }

        private void btnremove_Click(object sender, EventArgs e)
        {
            if (dataGridView1.SelectedRows.Count > 0)
            {
                try
                {
                    conn.Open();
                    string query = "DELETE FROM Books WHERE ID = @ID";
                    OleDbCommand cmd = new OleDbCommand(query, conn);

                    // Get the ID of the selected book
                    int bookID = Convert.ToInt32(dataGridView1.SelectedRows[0].Cells["ID"].Value);
                    cmd.Parameters.AddWithValue("@ID", bookID);

                    int rowsAffected = cmd.ExecuteNonQuery();
                    if (rowsAffected > 0)
                    {
                        MessageBox.Show("Book removed successfully!");
                        LoadData();  // Reload the DataGridView
                    }
                    else
                    {
                        MessageBox.Show("No book was found with the given ID.");
                    }
                }
                catch (Exception ex)
                {
                    MessageBox.Show("Error removing book: " + ex.Message);
                }
                finally
                {
                    conn.Close();
                }
            }
            else
            {
                MessageBox.Show("Please select a book to remove.");
            }

        }
        private void ClearFields()
        {
            tbtitle.Clear();
            tbquan.Clear();
        }

        private void dataGridView1_CellContentClick(object sender, DataGridViewCellEventArgs e)
        {

        }

        private void Inventory_Load(object sender, EventArgs e)
        {

        }

    }
}
