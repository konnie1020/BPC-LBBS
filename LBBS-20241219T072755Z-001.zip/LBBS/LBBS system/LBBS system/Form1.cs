﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using System.Data.OleDb;

namespace LBBS_system
{
    public partial class login : Form
    {
        public login()
        {
            InitializeComponent();
        }

        private void Form1_Load(object sender, EventArgs e)
        {

        }

        private void pictureBox1_Click(object sender, EventArgs e)
        {

        }

        private void panel1_Paint(object sender, PaintEventArgs e)
        {

        }

        private void lbforgotp_LinkClicked(object sender, LinkLabelLinkClickedEventArgs e)
        {
            // Create and show the ForgotPasswordForm when the link is clicked
            forgotpass forgotPasswordForm = new forgotpass();
            forgotPasswordForm.Show(); // Opens the new form
            this.Hide(); // Optionally hide the current form (LoginForm)
        }

        private void btnlogin_Click(object sender, EventArgs e)
        {
            

            string connectionString = @"Provider=Microsoft.ACE.OLEDB.12.0;Data Source=LBBS.accdb;";
            string username = tbUser.Text.Trim();
            string password = tbPass.Text.Trim();

            if (string.IsNullOrEmpty(username) || string.IsNullOrEmpty(password))
            {
                MessageBox.Show("Please enter both username and password.");
                return;
            }

            using (OleDbConnection connection = new OleDbConnection(connectionString))
            {
                try
                {
                    connection.Open();

                    // Check in the 'admin' table
                    string queryAdmin = "SELECT * FROM admin WHERE username = @username AND password = @password";
                    using (OleDbCommand commandAdmin = new OleDbCommand(queryAdmin, connection))
                    {
                        commandAdmin.Parameters.AddWithValue("@username", username);
                        commandAdmin.Parameters.AddWithValue("@password", password);

                        OleDbDataReader readerAdmin = commandAdmin.ExecuteReader();
                        if (readerAdmin.Read()) // Admin credentials match
                        {
                            MessageBox.Show("Welcome, Admin!");
                            this.Hide();
                            adminmenu adminForm = new adminmenu();
                            adminForm.Show();
                            return;
                        }
                    }

                    // Check in the 'user' table
                    string queryUser = "SELECT * FROM systemUser WHERE username = @username AND password = @password";
                    using (OleDbCommand commandUser = new OleDbCommand(queryUser, connection))
                    {
                        commandUser.Parameters.AddWithValue("@username", username);
                        commandUser.Parameters.AddWithValue("@password", password);

                        OleDbDataReader readerUser = commandUser.ExecuteReader();
                        if (readerUser.Read()) // User credentials match
                        {
                            MessageBox.Show("Welcome, User!");
                            this.Hide();
                            usermenu userForm = new usermenu();
                            userForm.Show();
                            return;
                        }
                    }

                    // If no match is found
                    MessageBox.Show("Invalid username or password.");
                }
                catch (Exception ex)
                {
                    MessageBox.Show("An error occurred: " + ex.Message);
                }
            }
        }
            

        private void tbUser_TextChanged(object sender, EventArgs e)
        {

        }
    }
}
