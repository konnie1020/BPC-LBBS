﻿namespace LBBS_system
{
    partial class userlist
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            System.ComponentModel.ComponentResourceManager resources = new System.ComponentModel.ComponentResourceManager(typeof(userlist));
            this.label5 = new System.Windows.Forms.Label();
            this.tbpos = new System.Windows.Forms.TextBox();
            this.label6 = new System.Windows.Forms.Label();
            this.tbemail = new System.Windows.Forms.TextBox();
            this.pictureBox1 = new System.Windows.Forms.PictureBox();
            this.btndel = new System.Windows.Forms.Button();
            this.btnedit = new System.Windows.Forms.Button();
            this.btnadd = new System.Windows.Forms.Button();
            this.label3 = new System.Windows.Forms.Label();
            this.ttbfn = new System.Windows.Forms.TextBox();
            this.label2 = new System.Windows.Forms.Label();
            this.tbln = new System.Windows.Forms.TextBox();
            this.label1 = new System.Windows.Forms.Label();
            this.tbid = new System.Windows.Forms.TextBox();
            this.dgv = new System.Windows.Forms.DataGridView();
            this.label4 = new System.Windows.Forms.Label();
            this.tbuser = new System.Windows.Forms.TextBox();
            this.flpMenu = new System.Windows.Forms.FlowLayoutPanel();
            this.panel2 = new System.Windows.Forms.Panel();
            this.menubtn = new System.Windows.Forms.PictureBox();
            this.label7 = new System.Windows.Forms.Label();
            this.panel3 = new System.Windows.Forms.Panel();
            this.btnHome = new System.Windows.Forms.Button();
            this.panel1 = new System.Windows.Forms.Panel();
            this.btnborrowlist = new System.Windows.Forms.Button();
            this.panel4 = new System.Windows.Forms.Panel();
            this.btnuserlist = new System.Windows.Forms.Button();
            this.panel8 = new System.Windows.Forms.Panel();
            this.btnrecords = new System.Windows.Forms.Button();
            this.panel9 = new System.Windows.Forms.Panel();
            this.btninven = new System.Windows.Forms.Button();
            this.btnsave = new System.Windows.Forms.Button();
            this.btncancel = new System.Windows.Forms.Button();
            this.panel11 = new System.Windows.Forms.Panel();
            this.button2 = new System.Windows.Forms.Button();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox1)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.dgv)).BeginInit();
            this.flpMenu.SuspendLayout();
            this.panel2.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.menubtn)).BeginInit();
            this.panel3.SuspendLayout();
            this.panel1.SuspendLayout();
            this.panel4.SuspendLayout();
            this.panel8.SuspendLayout();
            this.panel9.SuspendLayout();
            this.panel11.SuspendLayout();
            this.SuspendLayout();
            // 
            // label5
            // 
            this.label5.AutoSize = true;
            this.label5.Font = new System.Drawing.Font("Segoe UI", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label5.ForeColor = System.Drawing.Color.White;
            this.label5.Location = new System.Drawing.Point(244, 410);
            this.label5.Margin = new System.Windows.Forms.Padding(2, 0, 2, 0);
            this.label5.Name = "label5";
            this.label5.Size = new System.Drawing.Size(76, 21);
            this.label5.TabIndex = 37;
            this.label5.Text = "posistion:";
            // 
            // tbpos
            // 
            this.tbpos.Location = new System.Drawing.Point(327, 413);
            this.tbpos.Margin = new System.Windows.Forms.Padding(2, 2, 2, 2);
            this.tbpos.Name = "tbpos";
            this.tbpos.Size = new System.Drawing.Size(183, 20);
            this.tbpos.TabIndex = 36;
            this.tbpos.TextChanged += new System.EventHandler(this.tbbid_TextChanged);
            // 
            // label6
            // 
            this.label6.AutoSize = true;
            this.label6.Font = new System.Drawing.Font("Segoe UI", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label6.ForeColor = System.Drawing.Color.White;
            this.label6.Location = new System.Drawing.Point(269, 378);
            this.label6.Margin = new System.Windows.Forms.Padding(2, 0, 2, 0);
            this.label6.Name = "label6";
            this.label6.Size = new System.Drawing.Size(51, 21);
            this.label6.TabIndex = 35;
            this.label6.Text = "Email:";
            // 
            // tbemail
            // 
            this.tbemail.Location = new System.Drawing.Point(327, 378);
            this.tbemail.Margin = new System.Windows.Forms.Padding(2, 2, 2, 2);
            this.tbemail.Name = "tbemail";
            this.tbemail.Size = new System.Drawing.Size(183, 20);
            this.tbemail.TabIndex = 34;
            this.tbemail.TextChanged += new System.EventHandler(this.tbemail_TextChanged);
            // 
            // pictureBox1
            // 
            this.pictureBox1.Image = global::LBBS_system.Properties.Resources.lbbs_no_bg;
            this.pictureBox1.Location = new System.Drawing.Point(259, 12);
            this.pictureBox1.Name = "pictureBox1";
            this.pictureBox1.Size = new System.Drawing.Size(234, 197);
            this.pictureBox1.SizeMode = System.Windows.Forms.PictureBoxSizeMode.StretchImage;
            this.pictureBox1.TabIndex = 33;
            this.pictureBox1.TabStop = false;
            // 
            // btndel
            // 
            this.btndel.BackColor = System.Drawing.Color.Yellow;
            this.btndel.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.btndel.Font = new System.Drawing.Font("Segoe UI", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btndel.Location = new System.Drawing.Point(898, 469);
            this.btndel.Margin = new System.Windows.Forms.Padding(2, 2, 2, 2);
            this.btndel.Name = "btndel";
            this.btndel.Size = new System.Drawing.Size(110, 48);
            this.btndel.TabIndex = 32;
            this.btndel.Text = "Delete";
            this.btndel.UseVisualStyleBackColor = false;
            this.btndel.Click += new System.EventHandler(this.btndel_Click);
            // 
            // btnedit
            // 
            this.btnedit.BackColor = System.Drawing.Color.Yellow;
            this.btnedit.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.btnedit.Font = new System.Drawing.Font("Segoe UI", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btnedit.Location = new System.Drawing.Point(729, 469);
            this.btnedit.Margin = new System.Windows.Forms.Padding(2, 2, 2, 2);
            this.btnedit.Name = "btnedit";
            this.btnedit.Size = new System.Drawing.Size(110, 48);
            this.btnedit.TabIndex = 31;
            this.btnedit.Text = "Edit";
            this.btnedit.UseVisualStyleBackColor = false;
            this.btnedit.Click += new System.EventHandler(this.btnedit_Click);
            // 
            // btnadd
            // 
            this.btnadd.BackColor = System.Drawing.Color.Yellow;
            this.btnadd.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.btnadd.Font = new System.Drawing.Font("Segoe UI", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btnadd.Location = new System.Drawing.Point(565, 469);
            this.btnadd.Margin = new System.Windows.Forms.Padding(2, 2, 2, 2);
            this.btnadd.Name = "btnadd";
            this.btnadd.Size = new System.Drawing.Size(110, 48);
            this.btnadd.TabIndex = 30;
            this.btnadd.Text = "Add";
            this.btnadd.UseVisualStyleBackColor = false;
            this.btnadd.Click += new System.EventHandler(this.btnadd_Click);
            // 
            // label3
            // 
            this.label3.AutoSize = true;
            this.label3.Font = new System.Drawing.Font("Segoe UI", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label3.ForeColor = System.Drawing.Color.White;
            this.label3.Location = new System.Drawing.Point(238, 341);
            this.label3.Margin = new System.Windows.Forms.Padding(2, 0, 2, 0);
            this.label3.Name = "label3";
            this.label3.Size = new System.Drawing.Size(82, 21);
            this.label3.TabIndex = 29;
            this.label3.Text = "Firstname:";
            // 
            // ttbfn
            // 
            this.ttbfn.Location = new System.Drawing.Point(327, 342);
            this.ttbfn.Margin = new System.Windows.Forms.Padding(2, 2, 2, 2);
            this.ttbfn.Name = "ttbfn";
            this.ttbfn.Size = new System.Drawing.Size(183, 20);
            this.ttbfn.TabIndex = 28;
            this.ttbfn.TextChanged += new System.EventHandler(this.ttbfn_TextChanged);
            // 
            // label2
            // 
            this.label2.AutoSize = true;
            this.label2.Font = new System.Drawing.Font("Segoe UI", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label2.ForeColor = System.Drawing.Color.White;
            this.label2.Location = new System.Drawing.Point(240, 305);
            this.label2.Margin = new System.Windows.Forms.Padding(2, 0, 2, 0);
            this.label2.Name = "label2";
            this.label2.Size = new System.Drawing.Size(80, 21);
            this.label2.TabIndex = 27;
            this.label2.Text = "Lastname:";
            // 
            // tbln
            // 
            this.tbln.Location = new System.Drawing.Point(327, 305);
            this.tbln.Margin = new System.Windows.Forms.Padding(2, 2, 2, 2);
            this.tbln.Name = "tbln";
            this.tbln.Size = new System.Drawing.Size(183, 20);
            this.tbln.TabIndex = 26;
            this.tbln.TextChanged += new System.EventHandler(this.tbln_TextChanged);
            // 
            // label1
            // 
            this.label1.AutoSize = true;
            this.label1.Font = new System.Drawing.Font("Segoe UI", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label1.ForeColor = System.Drawing.Color.White;
            this.label1.Location = new System.Drawing.Point(260, 238);
            this.label1.Margin = new System.Windows.Forms.Padding(2, 0, 2, 0);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(60, 21);
            this.label1.TabIndex = 25;
            this.label1.Text = "StuffID:";
            // 
            // tbid
            // 
            this.tbid.Location = new System.Drawing.Point(327, 238);
            this.tbid.Margin = new System.Windows.Forms.Padding(2, 2, 2, 2);
            this.tbid.Name = "tbid";
            this.tbid.Size = new System.Drawing.Size(183, 20);
            this.tbid.TabIndex = 24;
            this.tbid.TextChanged += new System.EventHandler(this.tbid_TextChanged);
            // 
            // dgv
            // 
            this.dgv.AutoSizeColumnsMode = System.Windows.Forms.DataGridViewAutoSizeColumnsMode.Fill;
            this.dgv.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            this.dgv.Location = new System.Drawing.Point(525, 40);
            this.dgv.Margin = new System.Windows.Forms.Padding(2, 2, 2, 2);
            this.dgv.Name = "dgv";
            this.dgv.RowTemplate.Height = 24;
            this.dgv.SelectionMode = System.Windows.Forms.DataGridViewSelectionMode.FullRowSelect;
            this.dgv.Size = new System.Drawing.Size(516, 405);
            this.dgv.TabIndex = 23;
            this.dgv.CellClick += new System.Windows.Forms.DataGridViewCellEventHandler(this.dgv_CellClick);
            this.dgv.CellContentClick += new System.Windows.Forms.DataGridViewCellEventHandler(this.dgv_CellContentClick);
            // 
            // label4
            // 
            this.label4.AutoSize = true;
            this.label4.Font = new System.Drawing.Font("Segoe UI", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label4.ForeColor = System.Drawing.Color.White;
            this.label4.Location = new System.Drawing.Point(236, 272);
            this.label4.Margin = new System.Windows.Forms.Padding(2, 0, 2, 0);
            this.label4.Name = "label4";
            this.label4.Size = new System.Drawing.Size(84, 21);
            this.label4.TabIndex = 46;
            this.label4.Text = "Username:";
            // 
            // tbuser
            // 
            this.tbuser.Location = new System.Drawing.Point(327, 272);
            this.tbuser.Margin = new System.Windows.Forms.Padding(2, 2, 2, 2);
            this.tbuser.Name = "tbuser";
            this.tbuser.Size = new System.Drawing.Size(183, 20);
            this.tbuser.TabIndex = 45;
            this.tbuser.TextChanged += new System.EventHandler(this.tbuser_TextChanged);
            // 
            // flpMenu
            // 
            this.flpMenu.BackColor = System.Drawing.Color.ForestGreen;
            this.flpMenu.Controls.Add(this.panel2);
            this.flpMenu.Controls.Add(this.panel3);
            this.flpMenu.Controls.Add(this.panel1);
            this.flpMenu.Controls.Add(this.panel4);
            this.flpMenu.Controls.Add(this.panel8);
            this.flpMenu.Controls.Add(this.panel9);
            this.flpMenu.Controls.Add(this.panel11);
            this.flpMenu.Dock = System.Windows.Forms.DockStyle.Left;
            this.flpMenu.Location = new System.Drawing.Point(0, 0);
            this.flpMenu.MaximumSize = new System.Drawing.Size(252, 562);
            this.flpMenu.MinimumSize = new System.Drawing.Size(68, 561);
            this.flpMenu.Name = "flpMenu";
            this.flpMenu.Size = new System.Drawing.Size(210, 562);
            this.flpMenu.TabIndex = 47;
            // 
            // panel2
            // 
            this.panel2.Controls.Add(this.menubtn);
            this.panel2.Controls.Add(this.label7);
            this.panel2.Location = new System.Drawing.Point(3, 3);
            this.panel2.Name = "panel2";
            this.panel2.Size = new System.Drawing.Size(249, 103);
            this.panel2.TabIndex = 2;
            // 
            // menubtn
            // 
            this.menubtn.Cursor = System.Windows.Forms.Cursors.Hand;
            this.menubtn.Image = ((System.Drawing.Image)(resources.GetObject("menubtn.Image")));
            this.menubtn.Location = new System.Drawing.Point(9, 27);
            this.menubtn.Name = "menubtn";
            this.menubtn.Size = new System.Drawing.Size(50, 40);
            this.menubtn.SizeMode = System.Windows.Forms.PictureBoxSizeMode.StretchImage;
            this.menubtn.TabIndex = 1;
            this.menubtn.TabStop = false;
            // 
            // label7
            // 
            this.label7.AutoSize = true;
            this.label7.Font = new System.Drawing.Font("Segoe UI", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label7.ForeColor = System.Drawing.Color.White;
            this.label7.Location = new System.Drawing.Point(65, 37);
            this.label7.Name = "label7";
            this.label7.Size = new System.Drawing.Size(55, 21);
            this.label7.TabIndex = 1;
            this.label7.Text = "MENU";
            // 
            // panel3
            // 
            this.panel3.Controls.Add(this.btnHome);
            this.panel3.Location = new System.Drawing.Point(3, 112);
            this.panel3.Name = "panel3";
            this.panel3.Size = new System.Drawing.Size(249, 42);
            this.panel3.TabIndex = 3;
            // 
            // btnHome
            // 
            this.btnHome.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.btnHome.Font = new System.Drawing.Font("Segoe UI", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btnHome.ForeColor = System.Drawing.Color.White;
            this.btnHome.ImageAlign = System.Drawing.ContentAlignment.MiddleLeft;
            this.btnHome.Location = new System.Drawing.Point(-4, -15);
            this.btnHome.Name = "btnHome";
            this.btnHome.Size = new System.Drawing.Size(275, 72);
            this.btnHome.TabIndex = 2;
            this.btnHome.Text = "                Home";
            this.btnHome.TextAlign = System.Drawing.ContentAlignment.MiddleLeft;
            this.btnHome.UseVisualStyleBackColor = true;
            // 
            // panel1
            // 
            this.panel1.Controls.Add(this.btnborrowlist);
            this.panel1.Location = new System.Drawing.Point(3, 160);
            this.panel1.Name = "panel1";
            this.panel1.Size = new System.Drawing.Size(249, 42);
            this.panel1.TabIndex = 1;
            // 
            // btnborrowlist
            // 
            this.btnborrowlist.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.btnborrowlist.Font = new System.Drawing.Font("Segoe UI", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btnborrowlist.ForeColor = System.Drawing.Color.White;
            this.btnborrowlist.ImageAlign = System.Drawing.ContentAlignment.MiddleLeft;
            this.btnborrowlist.Location = new System.Drawing.Point(-5, -15);
            this.btnborrowlist.Name = "btnborrowlist";
            this.btnborrowlist.Size = new System.Drawing.Size(275, 72);
            this.btnborrowlist.TabIndex = 2;
            this.btnborrowlist.Text = "                Borrower List";
            this.btnborrowlist.TextAlign = System.Drawing.ContentAlignment.MiddleLeft;
            this.btnborrowlist.UseVisualStyleBackColor = true;
            // 
            // panel4
            // 
            this.panel4.Controls.Add(this.btnuserlist);
            this.panel4.Location = new System.Drawing.Point(3, 208);
            this.panel4.Name = "panel4";
            this.panel4.Size = new System.Drawing.Size(249, 42);
            this.panel4.TabIndex = 3;
            // 
            // btnuserlist
            // 
            this.btnuserlist.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.btnuserlist.Font = new System.Drawing.Font("Segoe UI", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btnuserlist.ForeColor = System.Drawing.Color.White;
            this.btnuserlist.ImageAlign = System.Drawing.ContentAlignment.MiddleLeft;
            this.btnuserlist.Location = new System.Drawing.Point(-4, -15);
            this.btnuserlist.Name = "btnuserlist";
            this.btnuserlist.Size = new System.Drawing.Size(275, 72);
            this.btnuserlist.TabIndex = 2;
            this.btnuserlist.Text = "                User List";
            this.btnuserlist.TextAlign = System.Drawing.ContentAlignment.MiddleLeft;
            this.btnuserlist.UseVisualStyleBackColor = true;
            // 
            // panel8
            // 
            this.panel8.Controls.Add(this.btnrecords);
            this.panel8.Location = new System.Drawing.Point(3, 256);
            this.panel8.Name = "panel8";
            this.panel8.Size = new System.Drawing.Size(249, 42);
            this.panel8.TabIndex = 8;
            // 
            // btnrecords
            // 
            this.btnrecords.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.btnrecords.Font = new System.Drawing.Font("Segoe UI", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btnrecords.ForeColor = System.Drawing.Color.White;
            this.btnrecords.ImageAlign = System.Drawing.ContentAlignment.MiddleLeft;
            this.btnrecords.Location = new System.Drawing.Point(-3, -13);
            this.btnrecords.Name = "btnrecords";
            this.btnrecords.Size = new System.Drawing.Size(275, 72);
            this.btnrecords.TabIndex = 2;
            this.btnrecords.Text = "                Records\r\n\r\n";
            this.btnrecords.TextAlign = System.Drawing.ContentAlignment.MiddleLeft;
            this.btnrecords.UseVisualStyleBackColor = true;
            // 
            // panel9
            // 
            this.panel9.Controls.Add(this.btninven);
            this.panel9.Location = new System.Drawing.Point(3, 304);
            this.panel9.Name = "panel9";
            this.panel9.Size = new System.Drawing.Size(249, 42);
            this.panel9.TabIndex = 9;
            // 
            // btninven
            // 
            this.btninven.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.btninven.Font = new System.Drawing.Font("Segoe UI", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btninven.ForeColor = System.Drawing.Color.White;
            this.btninven.ImageAlign = System.Drawing.ContentAlignment.MiddleLeft;
            this.btninven.Location = new System.Drawing.Point(-3, -15);
            this.btninven.Name = "btninven";
            this.btninven.Size = new System.Drawing.Size(275, 72);
            this.btninven.TabIndex = 2;
            this.btninven.Text = "                Inventory";
            this.btninven.TextAlign = System.Drawing.ContentAlignment.MiddleLeft;
            this.btninven.UseVisualStyleBackColor = true;
            // 
            // btnsave
            // 
            this.btnsave.BackColor = System.Drawing.Color.Yellow;
            this.btnsave.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.btnsave.Font = new System.Drawing.Font("Segoe UI", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btnsave.Location = new System.Drawing.Point(286, 469);
            this.btnsave.Margin = new System.Windows.Forms.Padding(2, 2, 2, 2);
            this.btnsave.Name = "btnsave";
            this.btnsave.Size = new System.Drawing.Size(110, 48);
            this.btnsave.TabIndex = 49;
            this.btnsave.Text = "save";
            this.btnsave.UseVisualStyleBackColor = false;
            // 
            // btncancel
            // 
            this.btncancel.BackColor = System.Drawing.Color.Yellow;
            this.btncancel.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.btncancel.Font = new System.Drawing.Font("Segoe UI", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btncancel.Location = new System.Drawing.Point(400, 469);
            this.btncancel.Margin = new System.Windows.Forms.Padding(2, 2, 2, 2);
            this.btncancel.Name = "btncancel";
            this.btncancel.Size = new System.Drawing.Size(110, 48);
            this.btncancel.TabIndex = 48;
            this.btncancel.Text = "cancel";
            this.btncancel.UseVisualStyleBackColor = false;
            this.btncancel.Click += new System.EventHandler(this.btncancel_Click);
            // 
            // panel11
            // 
            this.panel11.Controls.Add(this.button2);
            this.panel11.Location = new System.Drawing.Point(3, 352);
            this.panel11.Name = "panel11";
            this.panel11.Size = new System.Drawing.Size(249, 42);
            this.panel11.TabIndex = 10;
            // 
            // button2
            // 
            this.button2.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.button2.Font = new System.Drawing.Font("Segoe UI", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.button2.ForeColor = System.Drawing.Color.White;
            this.button2.ImageAlign = System.Drawing.ContentAlignment.MiddleLeft;
            this.button2.Location = new System.Drawing.Point(-1, -13);
            this.button2.Name = "button2";
            this.button2.Size = new System.Drawing.Size(275, 72);
            this.button2.TabIndex = 2;
            this.button2.Text = "                Log Out";
            this.button2.TextAlign = System.Drawing.ContentAlignment.MiddleLeft;
            this.button2.UseVisualStyleBackColor = true;
            this.button2.Click += new System.EventHandler(this.button2_Click);
            // 
            // userlist
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.BackColor = System.Drawing.Color.DarkGreen;
            this.ClientSize = new System.Drawing.Size(1098, 565);
            this.Controls.Add(this.btnsave);
            this.Controls.Add(this.btncancel);
            this.Controls.Add(this.flpMenu);
            this.Controls.Add(this.label4);
            this.Controls.Add(this.tbuser);
            this.Controls.Add(this.label5);
            this.Controls.Add(this.tbpos);
            this.Controls.Add(this.label6);
            this.Controls.Add(this.tbemail);
            this.Controls.Add(this.pictureBox1);
            this.Controls.Add(this.btndel);
            this.Controls.Add(this.btnedit);
            this.Controls.Add(this.btnadd);
            this.Controls.Add(this.label3);
            this.Controls.Add(this.ttbfn);
            this.Controls.Add(this.label2);
            this.Controls.Add(this.tbln);
            this.Controls.Add(this.label1);
            this.Controls.Add(this.tbid);
            this.Controls.Add(this.dgv);
            this.Name = "userlist";
            this.Text = "userlist";
            this.Load += new System.EventHandler(this.userlist_Load);
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox1)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.dgv)).EndInit();
            this.flpMenu.ResumeLayout(false);
            this.panel2.ResumeLayout(false);
            this.panel2.PerformLayout();
            ((System.ComponentModel.ISupportInitialize)(this.menubtn)).EndInit();
            this.panel3.ResumeLayout(false);
            this.panel1.ResumeLayout(false);
            this.panel4.ResumeLayout(false);
            this.panel8.ResumeLayout(false);
            this.panel9.ResumeLayout(false);
            this.panel11.ResumeLayout(false);
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion
        private System.Windows.Forms.Label label5;
        private System.Windows.Forms.TextBox tbpos;
        private System.Windows.Forms.Label label6;
        private System.Windows.Forms.TextBox tbemail;
        private System.Windows.Forms.PictureBox pictureBox1;
        private System.Windows.Forms.Button btndel;
        private System.Windows.Forms.Button btnedit;
        private System.Windows.Forms.Button btnadd;
        private System.Windows.Forms.Label label3;
        private System.Windows.Forms.TextBox ttbfn;
        private System.Windows.Forms.Label label2;
        private System.Windows.Forms.TextBox tbln;
        private System.Windows.Forms.Label label1;
        private System.Windows.Forms.TextBox tbid;
        private System.Windows.Forms.DataGridView dgv;
        private System.Windows.Forms.Label label4;
        private System.Windows.Forms.TextBox tbuser;
        private System.Windows.Forms.FlowLayoutPanel flpMenu;
        private System.Windows.Forms.Panel panel2;
        private System.Windows.Forms.PictureBox menubtn;
        private System.Windows.Forms.Label label7;
        private System.Windows.Forms.Panel panel3;
        private System.Windows.Forms.Button btnHome;
        private System.Windows.Forms.Panel panel1;
        private System.Windows.Forms.Button btnborrowlist;
        private System.Windows.Forms.Panel panel4;
        private System.Windows.Forms.Button btnuserlist;
        private System.Windows.Forms.Panel panel8;
        private System.Windows.Forms.Button btnrecords;
        private System.Windows.Forms.Panel panel9;
        private System.Windows.Forms.Button btninven;
        private System.Windows.Forms.Button btnsave;
        private System.Windows.Forms.Button btncancel;
        private System.Windows.Forms.Panel panel11;
        private System.Windows.Forms.Button button2;
    }
}