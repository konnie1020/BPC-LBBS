﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using System.Data.OleDb;

namespace LBBS_system
{
    public partial class userinven : Form
    {
        private OleDbConnection conn;
        public userinven()
        {
            InitializeComponent();
            conn = new OleDbConnection(@"Provider=Microsoft.ACE.OLEDB.12.0;Data Source=LBBS.accdb");
            LoadData();
        }

        private void LoadData()
        {

            string query = "SELECT * FROM Books"; // Adjust according to your table name
            OleDbDataAdapter adapter = new OleDbDataAdapter(query, conn); // Fetch data from the database
            DataTable dt = new DataTable(); // Create a DataTable to hold the data
            adapter.Fill(dt); // Fill the DataTable with data from the database

            dataGridView1.DataSource = dt; // Bind the data to your DataGridView
            conn.Close();
        }

        private bool IsDuplicateBook(string title)
        {
            conn.Open();
            string query = "SELECT COUNT(*) FROM Books WHERE Title = @Title";
            OleDbCommand cmd = new OleDbCommand(query, conn);
            cmd.Parameters.AddWithValue("@Title", title);

            int count = Convert.ToInt32(cmd.ExecuteScalar()); // Get the count of books with the same title
            conn.Close();

            return count > 0; // If more than 0, then it's a duplicate
        }

        private void numericUpDown1_ValueChanged(object sender, EventArgs e)
        {
            // Your code here
        }

        private void btnadd_Click(object sender, EventArgs e)
        {
            if (string.IsNullOrWhiteSpace(tbtitle.Text) || string.IsNullOrWhiteSpace(tbquan.Text))
            {
                MessageBox.Show("Please fill in all fields.");
                return;
            }

            if (IsDuplicateBook(tbtitle.Text))  // Check for duplicate book title
            {
                MessageBox.Show("This book already exists.");
                return;
            }

            conn.Open();
            string query = "INSERT INTO Books ([Title], [quantity]) VALUES " + " (@T, @Q)";
            OleDbCommand cmd = new OleDbCommand(query, conn);
            cmd.Parameters.AddWithValue("@T", tbtitle.Text);
            cmd.Parameters.AddWithValue("@Q", tbquan.Text);

            cmd.ExecuteNonQuery(); // Insert the new book into the database
            MessageBox.Show("Book added successfully!");

            LoadData();  // Reload the DataGridView with updated data
            ClearFields();  // Clear input fields after adding a book

            tbtitle.Focus();  // Focus on the title textbox for the next entry
            conn.Close();
        }

        private void btnremove_Click(object sender, EventArgs e)
        {
            if (dataGridView1.SelectedRows.Count > 0)
            {
                try
                {
                    // Ensure the selected row has a valid ID
                    var cellValue = dataGridView1.SelectedRows[0].Cells["ID"].Value;
                    if (cellValue == null || string.IsNullOrWhiteSpace(cellValue.ToString()))
                    {
                        MessageBox.Show("Invalid row selected. Please try again.");
                        return;
                    }

                    int bookID = Convert.ToInt32(cellValue);
                    MessageBox.Show($"Attempting to delete book with ID: {bookID}");

                    conn.Open();
                    string query = "DELETE FROM Books WHERE ID = @ID";
                    OleDbCommand cmd = new OleDbCommand(query, conn);
                    cmd.Parameters.AddWithValue("@ID", bookID);

                    int rowsAffected = cmd.ExecuteNonQuery();
                    if (rowsAffected > 0)
                    {
                        MessageBox.Show("Book removed successfully!");
                    }
                    else
                    {
                        MessageBox.Show("No book found with the selected ID.");
                    }

                    LoadData(); // Reload the DataGridView
                }
                catch (Exception ex)
                {
                    MessageBox.Show($"An error occurred: {ex.Message}");
                }
                finally
                {
                    if (conn.State == ConnectionState.Open)
                        conn.Close();
                }
            }
            else
            {
                MessageBox.Show("Please select a row to delete.");
            }
        }

        // Attach this method to the DataGridView's SelectionChanged event for debugging
        private void dataGridView1_SelectionChanged(object sender, EventArgs e)
        {
            if (dataGridView1.SelectedRows.Count > 0)
            {
                var selectedRow = dataGridView1.SelectedRows[0];
                var idValue = selectedRow.Cells["ID"].Value;
                MessageBox.Show($"Row selected with ID: {idValue}");
            }
        }


        private void ClearFields()
        {
            tbtitle.Clear();
            tbquan.Clear();
        }

        private void dataGridView1_CellContentClick(object sender, DataGridViewCellEventArgs e)
        {
            // Your code here
        }

        private void Inventory_Load(object sender, EventArgs e)
        {
            // Your code here
        }

        private void btnHome_Click(object sender, EventArgs e)
        {
            adminmenu adminmenu = new adminmenu();
            adminmenu.Show();
            this.Hide();
        }

        private void btnborrowlist_Click(object sender, EventArgs e)
        {
            borrowerList borrowerList = new borrowerList();
            borrowerList.Show(); // Opens the new form
            this.Hide(); // Optionally hide the current form (LoginFo
        }

        private void btnuserlist_Click(object sender, EventArgs e)
        {
            userlist userlist = new userlist();
            userlist.Show();
            this.Hide();
        }

        private void dataGridView1_CellClick(object sender, DataGridViewCellEventArgs e)
        {
            DataGridViewRow row = dataGridView1.Rows[e.RowIndex];
            tbid.Text = dataGridView1.CurrentRow.Cells[0].Value.ToString();
            tbtitle.Text = dataGridView1.CurrentRow.Cells[1].Value.ToString();
            tbquan.Text = dataGridView1.CurrentRow.Cells[2].Value.ToString();

        }

        private void btnrecords_Click(object sender, EventArgs e)
        {
            Records records = new Records();
            records.Show();
            this.Hide();
        }

        private void button2_Click(object sender, EventArgs e)
        {
            // Create and show the ForgotPasswordForm when the link is clicked
            login Form1 = new login();
            Form1.Show(); // Opens the new form
            this.Hide(); // Optionally hide the current form (LoginForm)
        }

        private void btninven_Click(object sender, EventArgs e)
        {
            Inventory Inventory = new Inventory();
            Inventory.Show();
            this.Hide();
        }

        private void flpMenu_Paint(object sender, PaintEventArgs e)
        {

        }

        private void tbid_TextChanged(object sender, EventArgs e)
        {

        }
    }
}


