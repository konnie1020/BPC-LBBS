﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using System.Data.OleDb; // For connecting to Access databases

namespace LBBS_system
{
    public partial class StudentList : Form
    {
        OleDbConnection conn; // Manages the connection to the Access database
        OleDbCommand cmd; // Executes SQL commands
        OleDbDataAdapter adapter; // Bridges data between Access and the application
        DataTable dt; // Stores data in-memory for binding to controls
        private bool isImageUploaded = false; // Tracks if an image is uploaded
        private bool topMenuExpand = false;
        private bool sidebarExpand = false;
        private bool isAnimating = false;

        public StudentList()
        {
            InitializeComponent();
            GetUsers();
            ClearTextBoxes();


        }

        void GetUsers()
        {
            conn = new OleDbConnection("Provider=Microsoft.ACE.OleDb.12.0;Data Source=LBBS.accdb");
            dt = new DataTable();
            adapter = new OleDbDataAdapter("SELECT * FROM StudentList", conn);
            conn.Open();
            adapter.Fill(dt);
            dgvUser.DataSource = dt;
            conn.Close();
        }


        private void dataGridView1_CellContentClick(object sender, DataGridViewCellEventArgs e)
        {

        }

        private void textBox1_TextChanged(object sender, EventArgs e)
        {

        }

        private void StudentList_Load(object sender, EventArgs e)
        {
            flpMenu.Width = flpMenu.MinimumSize.Width;
        }

        private void btnsave_Click(object sender, EventArgs e)
        {
            // Check for required fields
            if (string.IsNullOrWhiteSpace(tbfn.Text) || string.IsNullOrWhiteSpace(tbln.Text) ||
                string.IsNullOrWhiteSpace(tbemail.Text))
                
            {
                MessageBox.Show("Please fill in all fields.");
                return;
            }

           

            // SQL query to insert a new user
            string query = "INSERT INTO StudentList ( StudentID, Firstname, Lastname, Email) " +
                           "VALUES ( @id, @fn, @ln, @e)";
            cmd = new OleDbCommand(query, conn);

            // Add parameters from textboxes and controls
            cmd.Parameters.AddWithValue("@id", tbfn.Text);
            cmd.Parameters.AddWithValue("@fn", tbfn.Text);
            cmd.Parameters.AddWithValue("@ln", tbln.Text);
            cmd.Parameters.AddWithValue("@e", tbemail.Text);
           
           

            // Insert the new user
            conn.Open();
            cmd.ExecuteNonQuery();
            MessageBox.Show("User Inserted Successfully");
            conn.Close();

            // Refresh DataGridView
            GetUsers();
        }

        private void dgvUser_CellEnter(object sender, DataGridViewCellEventArgs e)
        {

           

        }

        private void btndel_Click(object sender, EventArgs e)
        {
            string query = "DELETE FROM StudentList WHERE StudentID = @id";
            cmd = new OleDbCommand(query, conn);
            cmd.Parameters.AddWithValue("@id", Convert.ToInt32(dgvUser.CurrentRow.Cells[0].Value));

            conn.Open();
            cmd.ExecuteNonQuery();
            MessageBox.Show("User Deleted");
            conn.Close();
            GetUsers();
        }

        private void btnupdate_Click(object sender, EventArgs e)
        {
            if (string.IsNullOrWhiteSpace(tbfn.Text) || string.IsNullOrWhiteSpace(tbln.Text) ||
                string.IsNullOrWhiteSpace(tbemail.Text))
            {
                MessageBox.Show("Please fill in all fields.");
                return;
            }

            string query = isImageUploaded
                ? "UPDATE StudentList SET Firstname=@fn, Lastname=@ln, Email=@bd WHERE ID=@id"
                : "UPDATE StudentList SET Firstname=@fn, Lastname=@ln, Email=@bd WHERE ID=@id";

            cmd = new OleDbCommand(query, conn);

            cmd.Parameters.AddWithValue("@fn", tbfn.Text);
            cmd.Parameters.AddWithValue("@ln", tbln.Text);
            cmd.Parameters.AddWithValue("@u", tbemail.Text);
               

            cmd.Parameters.AddWithValue("@id", Convert.ToInt32(dgvUser.CurrentRow.Cells[0].Value));

            conn.Open();
            cmd.ExecuteNonQuery();
            MessageBox.Show("User Updated Successfully");
            conn.Close();

            GetUsers();
        }

        private void btnclear_Click(object sender, EventArgs e)
        {
            tbID.Clear();
            tbfn.Clear();
            tbln.Clear();
            tbemail.Clear();

        }

        private void btnHome_Click(object sender, EventArgs e)
        {
            adminmenu adminmenu = new adminmenu();
            adminmenu.Show();
            this.Hide();
        }

        private void btnuserlist_Click(object sender, EventArgs e)
        {
            userlist userlist = new userlist();
            userlist.Show();
            this.Hide();
        }

        private void btnrecords_Click(object sender, EventArgs e)
        {
            Records records = new Records();
            records.Show();
            this.Hide();
        }

        private void button1_Click(object sender, EventArgs e)
        {
            StudentList studentlist = new StudentList();
            studentlist.Show();
            this.Hide();
        }

        private void btninven_Click(object sender, EventArgs e)
        {
            Inventory Inventory = new Inventory();
            Inventory.Show();
            this.Hide();
        }

        private void button2_Click(object sender, EventArgs e)
        {
            // Create and show the ForgotPasswordForm when the link is clicked
            login Form1 = new login();
            Form1.Show(); // Opens the new form
            this.Hide(); // Optionally hide the current form (LoginForm)
        }

        private void sidebarTimer_Tick(object sender, EventArgs e)
        {
            if (sidebarExpand)
            {
                // Expand the sidebar
                flpMenu.Width += 10; // Adjust for speed of expansion
                if (flpMenu.Width >= flpMenu.MaximumSize.Width)
                {
                    flpMenu.Width = flpMenu.MaximumSize.Width; // Snap to max size
                    isAnimating = false; // Stop animation
                    sidebarTimer.Stop();
                }
            }
            else
            {
                // Collapse the sidebar
                flpMenu.Width -= 10; // Adjust for speed of collapse
                if (flpMenu.Width <= flpMenu.MinimumSize.Width)
                {
                    flpMenu.Width = flpMenu.MinimumSize.Width; // Snap to min size
                    isAnimating = false; // Stop animation
                    sidebarTimer.Stop();
                }
            }
        }

        private void menubtn_Click(object sender, EventArgs e)
        {
            if (!isAnimating) // Prevent repeated triggering while animating
            {
                isAnimating = true;
                sidebarExpand = !sidebarExpand; // Toggle between expanding and collapsing
                sidebarTimer.Start(); // Start the animation timer
            }
        }

        private void btnborrowlist_Click(object sender, EventArgs e)
        {
            // Create and show the ForgotPasswordForm when the link is clicked
            borrowerList borrowerList = new borrowerList();
            borrowerList.Show(); // Opens the new form
            this.Hide();
        }
        private void ClearTextBoxes()
        {
            // Clear all the text boxes
            tbID.Clear();
            tbfn.Clear();
            tbln.Clear();
            tbemail.Clear();
        }

        private void dgvUser_CellClick(object sender, DataGridViewCellEventArgs e)
        {
            if (dgvUser.CurrentRow != null && dgvUser.CurrentRow.Index >= 0 && !dgvUser.CurrentRow.IsNewRow)
            {
                tbID.Text = dgvUser.CurrentRow.Cells[0].Value.ToString();
                tbfn.Text = dgvUser.CurrentRow.Cells[1].Value.ToString();
                tbln.Text = dgvUser.CurrentRow.Cells[2].Value.ToString();
                tbemail.Text = dgvUser.CurrentRow.Cells[3].Value.ToString();

            }
            else
            {
                // Clear the text boxes if no valid row is selected
                ClearTextBoxes();
            }
        }
    }
    }



