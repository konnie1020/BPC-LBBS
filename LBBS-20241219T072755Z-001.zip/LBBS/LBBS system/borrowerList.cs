﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using System.Data.OleDb;
using System.IO; // For handling file and memory streams

namespace LBBS_system
{
    public partial class borrowerList : Form
    {
        private OleDbConnection conn;
        private OleDbCommand cmd;
        private OleDbDataAdapter adapter;
        private DataTable dt;
        private bool isEditing = false;  // Track if we're editing an existing borrower
        private IFormatProvider borrowerID;
        private IFormatProvider bookID;
        private System.Windows.Forms.FlowLayoutPanel flpprofile;
        private bool topMenuExpand = false;
        private bool sidebarExpand = false; // Track whether the sidebar is expanded
        private bool isAnimating = false; // Prevent multiple triggers

        public borrowerList()
        {
            InitializeComponent();
            conn = new OleDbConnection(@"Provider=Microsoft.ACE.OLEDB.12.0;Data Source=LBBS.accdb");
            flpprofile = new FlowLayoutPanel(); // If you are creating this manually
            dtptoday.ValueChanged += dtptoday_ValueChanged;
            dtpdue.ValueChanged += dtpdue_ValueChanged;
        }

        private void borrowerList_Load(object sender, EventArgs e)
        {
            LoadData();
            flpMenu.Width = flpMenu.MinimumSize.Width;
            flpprofile.Width = flpprofile.MinimumSize.Width;

            string connectionString = @"Provider=Microsoft.ACE.OLEDB.12.0;Data Source=LBBS.accdb;";
            string query = "SELECT Title FROM Books WHERE [available] = True"; // Adjust query as needed

            using (OleDbConnection connection = new OleDbConnection(connectionString))
            {
               /* try*/
                {
                    connection.Open();
                    OleDbCommand command = new OleDbCommand(query, connection);
                    OleDbDataReader reader = command.ExecuteReader();

                    while (reader.Read())
                    {
                        string bookTitle = reader["Title"].ToString();
                        clbBooks.Items.Add(bookTitle); // Add book title to CheckedListBox
                    }
                }
                /*catch (Exception ex)
                {
                    MessageBox.Show("Error: " + ex.Message);
                }*/
            }

            try
            {
                conn.Open();
                adapter = new OleDbDataAdapter("SELECT * FROM BorrowerList", conn);
                dt = new DataTable();
                adapter.Fill(dt);

                // Add a new column for status (if not already part of the DataTable)
                if (!dt.Columns.Contains("ReturnStatus"))
                {
                    dt.Columns.Add("ReturnStatus");
                }

                // Loop through the data and set the status
                foreach (DataRow row in dt.Rows)
                {
                    DateTime dueDate = Convert.ToDateTime(row["DueDate"]);
                    string status = "";

                    if (dueDate < DateTime.Now.Date)
                    {
                        status = "Overdue";
                    }
                    else if (dueDate.Date == DateTime.Now.Date)
                    {
                        status = "Due Today";
                    }
                    else
                    {
                        status = "Not Due";
                    }

                    row["ReturnStatus"] = status;
                }

                dgv.DataSource = dt;
                conn.Close();
            }
            catch (Exception ex)
            {
                MessageBox.Show("Error: " + ex.Message);
                conn.Close();
            }
        }

        // Add Button Click (button1)
        private void button1_Click(object sender, EventArgs e)
        {
            if (isEditing)
            {
                UpdateBorrower();
            }
            else
            {
                AddBorrower();
            }

            // Ensure the required fields are not empty
            if (string.IsNullOrWhiteSpace(tbid.Text) || string.IsNullOrWhiteSpace(tbbookid.Text))
            {
               
            }

            // Validate the due date before adding
            if (dtpdue.Value.Date < dtptoday.Value.Date)
            {
                MessageBox.Show("The due date cannot be earlier than the borrowed date.");
                return;
            }

            if ((dtpdue.Value.Date - dtptoday.Value.Date).Days > 5)
            {
                MessageBox.Show("The maximum borrowing period is 5 days.");
                return;
            }

            // Continue with adding borrower logic...
            conn.Open();
            string query = "INSERT INTO BorrowerList (StudentID, LastName, FirstName, Email, BookID, Title, DateBorrowed, DueDate) VALUES " +
                            " (@borrowerID, @lastName, @firstName, @email, @bookID, @title, @dateBorrowed, @dueDate)";
            cmd = new OleDbCommand(query, conn);

            // Add parameters
            cmd.Parameters.AddWithValue("@borrowerID", tbid.Text);
            cmd.Parameters.AddWithValue("@lastName", tbln.Text);
            cmd.Parameters.AddWithValue("@firstName", tbfn.Text);
            cmd.Parameters.AddWithValue("@email", tbemail.Text);
            cmd.Parameters.AddWithValue("@bookID", tbbookid.Text);
            cmd.Parameters.AddWithValue("@title", tbtitle.Text);
            cmd.Parameters.AddWithValue("@dateBorrowed", dtptoday.Value);
            cmd.Parameters.AddWithValue("@dueDate", dtpdue.Value);

            cmd.ExecuteNonQuery();
            conn.Close();

            MessageBox.Show("Borrower added successfully!");
            ClearFields();
            LoadData();
        }

        // Save Button Click (btnsave)
        private void btnsave_Click(object sender, EventArgs e)
        {
            if (isEditing)
            {
                UpdateBorrower();
            }
            else
            {
                AddBorrower();
            }
        }

        // Cancel Button Click (btncancel)
        private void btncancel_Click(object sender, EventArgs e)
        {
            ClearFields();
            isEditing = false;
            
        }

        // Edit Button Click (btnedit)
        private void btnedit_Click(object sender, EventArgs e)
        {
            if (string.IsNullOrEmpty(tbid.Text))
            {
                MessageBox.Show("Please select a borrower to edit.");
                return;
            }

            isEditing = true;
            


            if (dtpdue.Value.Date < dtptoday.Value.Date)
            {
                MessageBox.Show("The due date cannot be earlier than the borrowed date.");
                return;
            }

            if ((dtpdue.Value.Date - dtptoday.Value.Date).Days > 5)
            {
                MessageBox.Show("The maximum borrowing period is 5 days.");
                return;
            }

            // Continue with updating borrower logic...
            conn.Open();
            string query = "UPDATE BorrowerList SET LastName=@ln, FirstName=@fn, Email=@em, BookID=@bookID, Title=@title, DateBorrowed=@borrowedDate, DueDate=@dueDate " +
                           "WHERE StudentID=@borrowerID";
            cmd = new OleDbCommand(query, conn);
            cmd.Parameters.AddWithValue("@ln", tbln.Text);
            cmd.Parameters.AddWithValue("@fn", tbfn.Text);
            cmd.Parameters.AddWithValue("@em", tbemail.Text);
            cmd.Parameters.AddWithValue("@bookID", tbbookid.Text);
            cmd.Parameters.AddWithValue("@title", tbtitle.Text);
            cmd.Parameters.AddWithValue("@borrowedDate", dtptoday.Value);
            cmd.Parameters.AddWithValue("@dueDate", dtpdue.Value);
            cmd.Parameters.AddWithValue("@borrowerID", tbid.Text);
            cmd.ExecuteNonQuery();
            conn.Close();

            MessageBox.Show("Borrower updated successfully!");
            ClearFields();
            LoadData();
        }

        // Delete Button Click (button3)
        private void button3_Click(object sender, EventArgs e)
        {
            if (string.IsNullOrEmpty(tbid.Text))
            {
                MessageBox.Show("Please select a borrower to delete.");
                return;
            }

            try
            {
                conn.Open();

                // Step 1: Transfer borrower information to BorrowingRecords table
                string transferQuery = "INSERT INTO BorrowingRecords (BookID, StudentID, BorrowDate, ReturnDate) " +
                                       "SELECT BookID, StudentID, DateBorrowed, DueDate FROM BorrowerList WHERE StudentID=@StudentID";
                cmd = new OleDbCommand(transferQuery, conn);
                cmd.Parameters.AddWithValue("@StudentID", tbid.Text);
                cmd.ExecuteNonQuery();

                // Step 2: Delete borrower from BorrowerList table
                string deleteQuery = "DELETE FROM BorrowerList WHERE StudentID=@StudentID";
                cmd = new OleDbCommand(deleteQuery, conn);
                cmd.Parameters.AddWithValue("@StudentID", tbid.Text);
                int result = cmd.ExecuteNonQuery();

                conn.Close();

                if (result > 0)
                {
                    MessageBox.Show("Borrower returned and information transferred successfully!");
                }
                else
                {
                    MessageBox.Show("Borrower not found or could not be deleted.");
                }

                ClearFields();
                LoadData();
            }
            catch (Exception ex)
            {
                MessageBox.Show("Error: " + ex.Message);
                conn.Close();
            }
        }

        // Add Borrower (Insert into DB)
        private void AddBorrower()
        {
            try
            {
                // Ensure the required fields are not empty
                if (string.IsNullOrWhiteSpace(tbid.Text) || string.IsNullOrWhiteSpace(tbbookid.Text))
                {
                    MessageBox.Show("Borrower ID and Book ID cannot be empty.");
                    return;
                }

                conn.Open();
                string query = "INSERT INTO BorrowerList (StudentID, LastName, FirstName, Email, BookID, Title, DateBorrowed, DueDate) VALUES " +
                                " (@borrowerID, @lastName, @firstName, @email, @bookID, @title, @dateBorrowed, @dueDate)";
                cmd = new OleDbCommand(query, conn);

                // Add parameters
                cmd.Parameters.AddWithValue("@borrowerID", tbid.Text); // Treat StudentID as a string
                cmd.Parameters.AddWithValue("@lastName", tbln.Text);
                cmd.Parameters.AddWithValue("@firstName", tbfn.Text);
                cmd.Parameters.AddWithValue("@email", tbemail.Text);
                cmd.Parameters.AddWithValue("@bookID", tbbookid.Text); // Treat BookID as a string
                cmd.Parameters.AddWithValue("@title", tbtitle.Text);
                cmd.Parameters.AddWithValue("@dateBorrowed", dtptoday.Value);
                cmd.Parameters.AddWithValue("@dueDate", dtpdue.Value);

                cmd.ExecuteNonQuery();
                conn.Close();

                MessageBox.Show("Borrower added successfully!");
                ClearFields();
                LoadData();
            }
            catch (Exception ex)
            {
                MessageBox.Show("Error: " + ex.Message);
                if (conn.State == ConnectionState.Open)
                {
                    conn.Close();
                }
            }
        }

        // Update Borrower (Edit in DB)
        private void UpdateBorrower()
        {
            try
            {
                conn.Open();
                string query = "UPDATE BorrowerList SET LastName=@ln, FirstName=@fn, Email=@em, BookID=@bookID, Title=@title, DateBorrowed=@borrowedDate, DueDate=@dueDate " +
                               "WHERE StudentID=@borrowerID";
                cmd = new OleDbCommand(query, conn);
                cmd.Parameters.AddWithValue("@ln", tbln.Text);
                cmd.Parameters.AddWithValue("@fn", tbfn.Text);
                cmd.Parameters.AddWithValue("@em", tbemail.Text);
                cmd.Parameters.AddWithValue("@bookID", tbbookid.Text);
                cmd.Parameters.AddWithValue("@title", tbtitle.Text);
                cmd.Parameters.AddWithValue("@borrowedDate", dtptoday.Value);
                cmd.Parameters.AddWithValue("@dueDate", dtpdue.Value);
                cmd.Parameters.AddWithValue("@borrowerID", tbid.Text);
                cmd.ExecuteNonQuery();
                conn.Close();
                MessageBox.Show("Borrower updated successfully!");
                ClearFields();
                LoadData();
            }
            catch (Exception ex)
            {
                MessageBox.Show("Error: " + ex.Message);
                conn.Close();
            }
        }

        // Load Data into DataGridView
        private void LoadData()
        {
            try
            {
                conn.Open();
                adapter = new OleDbDataAdapter("SELECT * FROM BorrowerList", conn);
                dt = new DataTable();
                adapter.Fill(dt);
                dgv.DataSource = dt;
                conn.Close();
            }
            catch (Exception ex)
            {
                MessageBox.Show("Error: " + ex.Message);
                conn.Close();
            }
        }

        // Clear TextBox Fields
        private void ClearFields()
        {
            tbid.Text = "";
            tbln.Text = "";
            tbfn.Text = "";
            tbemail.Text = "";
            tbbookid.Text = "";
            tbtitle.Text = "";
            dtptoday.Value = DateTime.Now;
            dtpdue.Value = DateTime.Now.AddDays(7);
        }

        // DataGridView Cell Click to populate fields for editing
        private void dgv_CellContentClick(object sender, DataGridViewCellEventArgs e)
        {
            
        }

        // TextChanged Events (Optional handling, can be used for validation or formatting)
        private void tbid_TextChanged(object sender, EventArgs e)
        {
            // Handle changes here if needed
            if (string.IsNullOrWhiteSpace(tbid.Text))
            {
                ClearFields();
                return;
            }

            try
            {
                conn.Open();
                string query = "SELECT LastName, FirstName, Email FROM StudentList WHERE StudentID = @StudentID";
                cmd = new OleDbCommand(query, conn);
                cmd.Parameters.AddWithValue("@StudentID", tbid.Text);

                OleDbDataReader reader = cmd.ExecuteReader();

                if (reader.Read())
                {
                    tbln.Text = reader["LastName"].ToString();
                    tbfn.Text = reader["FirstName"].ToString();
                    tbemail.Text = reader["Email"].ToString();
                }
                else
                {
                    // Clear fields if no match is found
                    tbln.Text = "";
                    tbfn.Text = "";
                    tbemail.Text = "";
                }

                reader.Close();
                conn.Close();
            }
            catch (Exception ex)
            {
                MessageBox.Show("Error: " + ex.Message);
                if (conn.State == ConnectionState.Open)
                {
                    conn.Close();
                }
            }
        }

        private void tbln_TextChanged(object sender, EventArgs e)
        {
            // Handle changes here if needed
        }

        private void tbfn_TextChanged(object sender, EventArgs e)
        {
            // Handle changes here if needed
        }

        private void tbemail_TextChanged(object sender, EventArgs e)
        {
            // Handle changes here if needed
        }

        private void tbbookid_TextChanged(object sender, EventArgs e)
        {
            // Handle changes here if needed
        }

        private void tbtitle_TextChanged(object sender, EventArgs e)
        {
            // Handle changes here if needed
        }

        private void dtptoday_ValueChanged(object sender, EventArgs e)
        {
            // Handle changes here if needed
            // Ensure dtptoday cannot be set to a date before today
            if (dtptoday.Value.Date < DateTime.Now.Date)
            {
               
                dtptoday.Value = DateTime.Now.Date; // Reset to today's date
            }

            // Ensure dtpdue is not earlier than dtptoday
            if (dtpdue.Value.Date < dtptoday.Value.Date)
            {
               
                dtpdue.Value = dtptoday.Value.Date.AddDays(5); // Reset to default due date
            }
        }

        private void dtpdue_ValueChanged(object sender, EventArgs e)
        {
            DateTime today = dtptoday.Value.Date;
            DateTime dueDate = dtpdue.Value.Date;

            // Check if dueDate is before today
            if (dueDate < today)
            {
                
                dtpdue.Value = today; // Reset to today's date
                return;
            }

            // Check if dueDate is more than 5 days from today
            if ((dueDate - today).Days > 5)
            {
               
                dtpdue.Value = today.AddDays(5); // Reset to the max allowed date
            }
        }
        private void label1_Click(object sender, EventArgs e)
        {

        }

        private void menubtn_Click(object sender, EventArgs e)
        {
            if (!isAnimating) // Prevent repeated triggering while animating
            {
                isAnimating = true;
                sidebarExpand = !sidebarExpand; // Toggle between expanding and collapsing
                sidemenu.Start(); // Start the animation timer
            }
        }

        private void sidemenu_Tick(object sender, EventArgs e)
        {
            if (sidebarExpand)
            {
                // Expand the sidebar
                flpMenu.Width += 10; // Adjust for speed of expansion
                if (flpMenu.Width >= flpMenu.MaximumSize.Width)
                {
                    flpMenu.Width = flpMenu.MaximumSize.Width; // Snap to max size
                    isAnimating = false; // Stop animation
                    sidemenu.Stop();
                }
            }
            else
            {
                // Collapse the sidebar
                flpMenu.Width -= 10; // Adjust for speed of collapse
                if (flpMenu.Width <= flpMenu.MinimumSize.Width)
                {
                    flpMenu.Width = flpMenu.MinimumSize.Width; // Snap to min size
                    isAnimating = false; // Stop animation
                    sidemenu.Stop();
                }
            }
        }

        private void flpMenu_Paint(object sender, PaintEventArgs e)
        {

        }

        private void btnHome_Click(object sender, EventArgs e)
        {
            adminmenu adminmenu = new adminmenu();
            adminmenu.Show();
            this.Hide();
        }

        private void dgv_CellClick(object sender, DataGridViewCellEventArgs e)
        {
            if (e.RowIndex >= 0)
            {
                DataGridViewRow row = dgv.Rows[e.RowIndex];
                tbid.Text = row.Cells["StudentID"].Value.ToString();
                tbln.Text = row.Cells["LastName"].Value.ToString();
                tbfn.Text = row.Cells["FirstName"].Value.ToString();
                tbemail.Text = row.Cells["Email"].Value.ToString();
                tbbookid.Text = row.Cells["BookID"].Value.ToString();
                tbtitle.Text = row.Cells["Title"].Value.ToString();
                dtptoday.Value = Convert.ToDateTime(row.Cells["DateBorrowed"].Value);
                dtpdue.Value = Convert.ToDateTime(row.Cells["DueDate"].Value);
            }
        }

        private void btnuserlist_Click(object sender, EventArgs e)
        {
            userlist userlist = new userlist();
            userlist.Show();
            this.Hide();
        }

        private void button2_Click(object sender, EventArgs e)
        {
            // Create and show the ForgotPasswordForm when the link is clicked
            login Form1 = new login();
            Form1.Show(); // Opens the new form
            this.Hide(); // Optionally hide the current form (LoginForm)
        }

        private void btnrecords_Click(object sender, EventArgs e)
        {
            Records records = new Records();
            records.Show();
            this.Hide();
        }

        private void btninven_Click(object sender, EventArgs e)
        {
            Inventory Inventory = new Inventory();
            Inventory.Show();
            this.Hide();
        }

        private void btnfinal_Click(object sender, EventArgs e)
        {
            
            
        }

        private void clbBooks_SelectedIndexChanged(object sender, EventArgs e)
        {
            StringBuilder selectedBooks = new StringBuilder(); // To hold multiple titles
            string selectedBookIDs = "";

            // Iterate through all checked items
            foreach (var item in clbBooks.CheckedItems)
            {
                selectedBooks.Append(item.ToString() + ", "); // Add the book title to the StringBuilder
                                                              // Optionally, you could fetch corresponding BookIDs here if needed
                selectedBookIDs += GetBookIDFromTitle(item.ToString()) + ", "; // Get BookID for each selected book
            }

            // Remove the trailing comma and space
            tbtitle.Text = selectedBooks.ToString().TrimEnd(',', ' ');
            tbbookid.Text = selectedBookIDs.TrimEnd(',', ' '); // Set the BookIDs in tbbookid
        }
        private string GetBookIDFromTitle(string bookTitle)
        {
            string bookID = "";
            try
            {
                conn.Open();
                string query = "SELECT ID FROM Books WHERE Title = @Title";
                cmd = new OleDbCommand(query, conn);
                cmd.Parameters.AddWithValue("@Title", bookTitle);
                OleDbDataReader reader = cmd.ExecuteReader();

                if (reader.Read())
                {
                    bookID = reader["ID"].ToString();
                }

                reader.Close();
                conn.Close();
            }
            catch (Exception ex)
            {
                MessageBox.Show("Error: " + ex.Message);
            }
            return bookID;
        }

        private void btnborrowlist_Click(object sender, EventArgs e)
        {

        }

        private void dgv_CellFormatting(object sender, DataGridViewCellFormattingEventArgs e)
        {
            if (e.RowIndex >= 0 && dgv.Columns[e.ColumnIndex].Name == "ReturnStatus")
            {
                DataGridViewRow row = dgv.Rows[e.RowIndex];
                DateTime dueDate = Convert.ToDateTime(row.Cells["DueDate"].Value);
                string status = "";

                if (dueDate < DateTime.Now.Date)
                {
                    status = "Overdue";
                }
                else if (dueDate.Date == DateTime.Now.Date)
                {
                    status = "Due Today";
                }
                else
                {
                    status = "Not Due";
                }

                e.Value = status;
            }

        }

        private void button3_Click_1(object sender, EventArgs e)
        {
            StudentList studentlist = new StudentList();
            studentlist.Show();
            this.Hide();
        }
    }
}
