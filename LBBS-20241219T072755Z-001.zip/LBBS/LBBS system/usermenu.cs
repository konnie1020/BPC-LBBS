﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace LBBS_system
{
    public partial class usermenu : Form
    {
        public usermenu()
        {
            InitializeComponent();
        }

        private void btnborrowlist_Click(object sender, EventArgs e)
        {
            
            UserBorrowerList borrowerList = new UserBorrowerList();
            borrowerList.Show(); 
            this.Hide(); 
        }

        private void btnrecords_Click(object sender, EventArgs e)
        {
            userhistory histo = new userhistory();
            histo.Show(); // Opens the new form
            this.Hide();
        }

        private void btninven_Click(object sender, EventArgs e)
        {
            userinven inven = new userinven();
            inven.Show(); // Opens the new form
            this.Hide();
        }

        private void button6_Click(object sender, EventArgs e)
        {

        }

        private void button1_Click(object sender, EventArgs e)
        {
            forgotpass forgotpass = new forgotpass();
            forgotpass.Show();
            this.Hide();
        }

        private void button2_Click(object sender, EventArgs e)
        {
            // Create and show the ForgotPasswordForm when the link is clicked
            login Form1 = new login();
            Form1.Show(); // Opens the new form
            this.Hide(); // Optionally hide the current form (LoginForm)
        }

        private void btnHome_Click(object sender, EventArgs e)
        {

        }
    }
    }

