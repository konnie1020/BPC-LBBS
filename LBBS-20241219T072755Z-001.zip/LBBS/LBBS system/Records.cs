﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using System.Data.OleDb; // For connecting to Access databases
using System.IO; // For handling file and memory streams


namespace LBBS_system
{
    public partial class Records : Form
    {
        OleDbConnection conn;// OleDbConnection: Manages database connection.
        OleDbCommand cmd; // OleDbCommand: Executes SQL commands (e.g., INSERT, UPDATE).
        OleDbDataAdapter adapter;// OleDbDataAdapter: Connects database and DataTable, retrieves and updates data.
        DataTable dt; // DataTable: Stores data in-memory, can be bound to controls like DataGridView.
        public Records()
        {
            InitializeComponent();
        }
        void GetUsers()
        {
            // Establish the connection string to connect to the Access database
            conn = new OleDbConnection("Provider= Microsoft.ACE.OleDb.12.0;Data Source=LBBS.accdb");
            // Initialize the DataTable to hold user data
            dt = new DataTable();
            // Set up an adapter to run the query and fetch the user data
            adapter = new OleDbDataAdapter("SELECT * FROM BorrowingRecords", conn);
            // Open the connection
            conn.Open();
            // Fill the DataTable with the result of the query
            adapter.Fill(dt);
            // Bind the DataTable to the DataGridView to display user information
            dataGridView1.DataSource = dt;
            // Close the database connection
            conn.Close();

        }

        private void button2_Click(object sender, EventArgs e)
        {
            // Create and show the ForgotPasswordForm when the link is clicked
            login Form1 = new login();
            Form1.Show(); // Opens the new form
            this.Hide(); // Optionally hide the current form (LoginForm)
        }

        private void Records_Load(object sender, EventArgs e)
        {
            GetUsers();
        }

        private void flowLayoutPanel1_Paint(object sender, PaintEventArgs e)
        {

        }

        private void btnHome_Click(object sender, EventArgs e)
        {
            adminmenu adminmenu = new adminmenu();
            adminmenu.Show();
            this.Hide();
        }

        private void btnborrowlist_Click(object sender, EventArgs e)
        {
            borrowerList borrowerList = new borrowerList();
            borrowerList.Show(); // Opens the new form
            this.Hide();
        }

        private void btnuserlist_Click(object sender, EventArgs e)
        {
            userlist userlist = new userlist();
            userlist.Show();
            this.Hide();
        }

        private void btnrecords_Click(object sender, EventArgs e)
        {
            Records records = new Records();
            records.Show();
            this.Hide();
        }

        private void btninven_Click(object sender, EventArgs e)
        {
            Inventory Inventory = new Inventory();
            Inventory.Show();
            this.Hide();
        }
    }
}
